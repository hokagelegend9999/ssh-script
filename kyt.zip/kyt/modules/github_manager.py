import requests
import base64
import json
import os
from datetime import datetime

# ==========================================
# KONFIGURASI (LOAD DARI VAR.TXT)
# ==========================================
VAR_FILE = "/usr/bin/kyt/var.txt"

def load_config(key_target):
    try:
        if not os.path.exists(VAR_FILE): return None
        with open(VAR_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'): continue
                if '=' in line:
                    key, value = line.split('=', 1)
                    if key.strip() == key_target:
                        return value.strip().strip('"').strip("'")
    except Exception as e:
        print(f"Error reading var.txt: {e}")
    return None

GITHUB_TOKEN = load_config("GITHUB_TOKEN")
REPO_OWNER = load_config("REPO_OWNER")
REPO_NAME = load_config("REPO_NAME")
FILE_PATH = load_config("FILE_PATH")
BRANCH = load_config("BRANCH") or "main"

# ==========================================
# FUNGSI DASAR API GITHUB
# ==========================================

def get_github_file():
    if not GITHUB_TOKEN or not REPO_OWNER:
        return None, "Konfigurasi GitHub di var.txt belum lengkap!"

    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{FILE_PATH}?ref={BRANCH}"
    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    r = requests.get(url, headers=headers)
    if r.status_code == 200:
        data = r.json()
        content_encoded = data['content']
        sha = data['sha']
        content_decoded = base64.b64decode(content_encoded).decode('utf-8')
        return content_decoded, sha
    return None, None

def update_github_file(new_content, sha, message):
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{FILE_PATH}"
    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    content_encoded = base64.b64encode(new_content.encode('utf-8')).decode('utf-8')
    payload = {
        "message": message,
        "content": content_encoded,
        "sha": sha,
        "branch": BRANCH
    }
    r = requests.put(url, headers=headers, data=json.dumps(payload))
    return r.status_code in [200, 201]

# ==========================================
# FUNGSI UTAMA (DISESUAIKAN DENGAN BOT)
# ==========================================

def add_ip_to_github(username, ip_addr, exp_date):
    """Menambahkan IP dengan format string return untuk bot"""
    content, sha = get_github_file()
    
    if content is None:
        return "❌ Gagal koneksi ke GitHub atau Config salah."
    
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    
    # Cek Duplikat
    for line in lines:
        if ip_addr in line:
            return f"❌ IP {ip_addr} sudah terdaftar!"
    
    # Format Data Baru: ### username exp ip status
    new_entry = f"### {username} {exp_date} {ip_addr} ON"
    lines.append(new_entry)
    
    new_content = "\n".join(lines)
    
    success = update_github_file(new_content, sha, f"Add IP {ip_addr}")
    if success:
        return f"✅ Berhasil menambahkan IP: {ip_addr}"
    else:
        return "❌ Gagal update ke GitHub (API Error)."

def remove_ip_from_github(ip_addr):
    """Menghapus IP dengan nama fungsi yang sesuai main.py"""
    content, sha = get_github_file()
    
    if content is None:
        return "❌ Gagal koneksi ke GitHub."
    
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    new_lines = []
    found = False
    
    # Filter IP
    for line in lines:
        parts = line.split()
        # Format: ### username exp ip status (IP ada di index 3)
        if len(parts) >= 4 and parts[3] == ip_addr:
            found = True
            continue 
        new_lines.append(line)
    
    if not found:
        return f"❌ IP {ip_addr} tidak ditemukan di database."
    
    new_content = "\n".join(new_lines)
    success = update_github_file(new_content, sha, f"Delete IP {ip_addr}")
    
    if success:
        return f"✅ Berhasil menghapus IP: {ip_addr}"
    else:
        return "❌ Gagal update ke GitHub."

def edit_ip_on_github(old_ip, username, new_ip, expired):
    """Mengedit IP (Hapus lama -> Tambah baru)"""
    # 1. Hapus IP Lama
    res_del = remove_ip_from_github(old_ip)
    if "❌" in res_del and "tidak ditemukan" not in res_del:
        return res_del # Return error jika gagal hapus (kecuali error not found)

    # 2. Tambah IP Baru
    res_add = add_ip_to_github(username, new_ip, expired)
    return res_add