from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging
from kyt.modules import config 

# =================================================================
# KONFIGURASI AWAL
# =================================================================
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# =================================================================
# 1. LOAD VARIABEL DARI var.txt (METODE PARSING AMAN)
# =================================================================
# Kita inisialisasi variabel global dengan nilai default
BOT_TOKEN = None
ADMIN = "0"
DOMAIN = ""
PUB = ""
HOST = ""
GITHUB_TOKEN = ""
REPO_OWNER = ""
REPO_NAME = ""
FILE_PATH = "alpha"
BRANCH = "main"

try:
    var_path = "kyt/var.txt" 
    if not os.path.exists(var_path):
        var_path = "/usr/bin/kyt/var.txt" # Fallback path
    
    if os.path.exists(var_path):
        with open(var_path, 'r') as f:
            for line in f:
                # Bersihkan spasi kiri kanan dan baris baru
                line = line.strip()
                # Skip baris kosong atau komentar
                if not line or line.startswith('#'):
                    continue
                
                # Pisahkan Key dan Value berdasarkan tanda sama dengan pertama
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'") # Hapus kutip jika ada
                    
                    # Masukkan ke variabel global
                    if key == "BOT_TOKEN": BOT_TOKEN = value
                    elif key == "ADMIN": ADMIN = value
                    elif key == "DOMAIN": DOMAIN = value
                    elif key == "PUB": PUB = value
                    elif key == "HOST": HOST = value
                    elif key == "GITHUB_TOKEN": GITHUB_TOKEN = value
                    elif key == "REPO_OWNER": REPO_OWNER = value
                    elif key == "REPO_NAME": REPO_NAME = value
                    elif key == "FILE_PATH": FILE_PATH = value
                    elif key == "BRANCH": BRANCH = value
                    
                    # Simpan juga ke globals() agar bisa diakses modul lain via exec() legacy
                    globals()[key] = value
    else:
        print(f"⚠️ var.txt tidak ditemukan di: {var_path}")

except Exception as e:
    print(f"⚠️ Error loading var.txt: {e}")

# Pastikan variable aman (Anti Crash)
if not BOT_TOKEN: 
    print("❌ BOT_TOKEN tidak ditemukan di var.txt! Bot berhenti.")
    sys.exit(1) # Exit code 1 agar systemd tahu ini error

# =================================================================
# 2. START BOT TELEGRAM CLIENT
# =================================================================
try:
    # API ID & Hash Default (Generic Telethon)
    api_id = 2040
    api_hash = "b18441a1ff607e10a989891a5462e627"
    
    # Session name 'kyt_session' agar tidak perlu login ulang
    # Menggunakan path absolut untuk session agar tidak error saat restart systemd
    session_path = "/usr/bin/kyt/kyt_session"
    
    bot = TelegramClient(session_path, api_id, api_hash).start(bot_token=BOT_TOKEN)
    print("✅ Telegram Client Berjalan...")
except Exception as e:
    print(f"❌ Error starting TelegramClient: {e}")
    sys.exit(1)

# =================================================================
# 3. SETUP DATABASE
# =================================================================
try:
    db_path = "/usr/bin/kyt/database.db"
    
    x = sqlite3.connect(db_path, check_same_thread=False)
    c = x.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
    
    # --- AUTO INJECT ADMIN (SUPPORT MULTI ID) ---
    list_admin_txt = [x.strip() for x in str(ADMIN).split(',')]
    
    for adm_id in list_admin_txt:
        if adm_id and adm_id != "0":
            c.execute("SELECT user_id FROM admin WHERE user_id = ?", (adm_id,))
            if c.fetchone() is None:
                c.execute("INSERT INTO admin (user_id) VALUES (?)", (adm_id,))
                print(f"➕ Admin Ditambahkan ke DB: {adm_id}")
            
    x.commit()
    x.close()
except Exception as e:
    print(f"❌ Error init database: {e}")

# =================================================================
# FUNGSI GLOBAL PEMBANTU (INIT)
# =================================================================

def get_db():
    """Membuka koneksi database"""
    path = "/usr/bin/kyt/database.db"
    x = sqlite3.connect(path, check_same_thread=False)
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    """
    Fungsi Validasi Admin SUPER LENGKAP
    Mengecek: Config, Var.txt, dan Database
    """
    check_id = str(id).strip()
    
    # 1. CEK DARI CONFIG.PY (OWNER UTAMA)
    try:
        if hasattr(config, 'OWNER_ID'):
            owners = [x.strip() for x in str(config.OWNER_ID).split(',')]
            if check_id in owners:
                return "true"
    except: pass

    # 2. CEK DARI VAR.TXT (GLOBAL VARIABLE)
    try:
        # Langsung cek variabel global ADMIN yang sudah kita parsing di atas
        admins_txt = [x.strip() for x in str(ADMIN).split(',')]
        if check_id in admins_txt:
            return "true"
    except: pass

    # 3. CEK DARI DATABASE (BACKUP TERAKHIR)
    conn = None
    try:
        conn = get_db()
        cursor = conn.execute("SELECT user_id FROM admin")
        all_admins = cursor.fetchall()
        
        admin_list_db = [str(row[0]).strip() for row in all_admins]
        
        if check_id in admin_list_db:
            return "true"
            
    except Exception as e:
        print(f"Error in valid(): {e}")
        
    finally:
        if conn: conn.close()
        
    return "false"

def convert_size(size_bytes):
    """Konversi bytes ke KB, MB, GB"""
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])