from kyt import *
from telethon import events, Button
from kyt.modules import harga, config, database, atlantic
import subprocess
import requests
import random
import io
import urllib.parse
import os
import json
import time
import asyncio
from telethon import errors
from kyt.modules import github_manager
import paramiko
from datetime import datetime

# =================================================================
# GLOBAL VARIABLES (STATE MACHINE)
# =================================================================
user_states = {}   # Untuk User Topup
admin_states = {}  # Untuk Admin Manage User
admin_context = {} # Penyimpanan data sementara Admin
WD_FILE = '/usr/bin/kyt/modules/wd_list.json'

# --- KONFIGURASI ADMIN UNTUK TOPUP MANUAL ---
ADMIN_WA = "6287726917005"  # Format: 628xx (Tanpa +)
ADMIN_TG = "HookageLegend"  # Username tanpa @

# FUNGSI CEK PROFILE ATLANTIC
def cek_atlantic():
    url = "https://atlantich2h.com/get_profile"
    try:
        payload = {'api_key': config.ATLANTIC_KEY.strip(), 'status': 'aktif'}
        r = requests.post(url, data=payload, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        res = r.json()
        
        status_api = str(res.get('status', 'false')).lower()
        if status_api == 'true':
            data = res['data']
            return data['name'], f"Rp {int(data['balance']):,}".replace(",", ".")
        else:
            return f"Err: {res.get('message', 'Gagal')}", "Rp 0"
    except:
        return "Connection Error", "Rp 0"

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.CallbackQuery(data=b'menu_as_user'))
async def menu_handler(event):
    try:
        sender = await event.get_sender()
        user_id = sender.id
        first_name = sender.first_name
        
        # Reset State saat buka menu agar tidak nyangkut
        if user_id in user_states: del user_states[user_id]
        if user_id in admin_states: del admin_states[user_id]
    except:
        user_id = "Unknown"; first_name = "User"

    if isinstance(event, events.CallbackQuery.Event):
        await event.answer()

    try:
        is_real_admin = False
        try:
            if valid(str(user_id)) == "true": is_real_admin = True
        except: pass

        view_as_user = False
        if hasattr(event, 'data') and event.data == b'menu_as_user':
            view_as_user = True

        # ==========================================
        # TAMPILAN KHUSUS ADMIN (Real Admin)
        # ==========================================
        if is_real_admin and not view_as_user:
            try:
                ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            except: ipsaya = "127.0.0.1"

            atl_nama, atl_saldo = cek_atlantic()

            msg = f"""
<b>👑 ADMIN CONTROL PANEL</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Admin :</b> {first_name}
<b>📡 IP    :</b> {ipsaya}

<b>💰 ATLANTIC H2H PROFILE</b>
<b>👤 Nama  :</b> <code>{atl_nama}</code>
<b>💵 Saldo :</b> <code>{atl_saldo}</code>

<b>📊 MENU MANAJEMEN:</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            buttons = [
                [Button.inline("☁️ SSH OVPN", data="ssh"), Button.inline("⚡ VMESS", data="vmess")],
                [Button.inline("🚀 VLESS", data="vless"), Button.inline("🛡 TROJAN", data="trojan")],
                [Button.inline("👻 SHADOWSOCKS", data="shadowsocks"), Button.inline("⚙️ SETTINGS", data="setting")],
                [Button.inline("🖥 SYSTEM INFO", data="info"), Button.inline("📝 REGIS IP (GITHUB)", data="gh_regis_menu")],
                [Button.inline("👥 MANAGE USER", data="manage_users"), Button.inline("💸 WITHDRAW", data="adm_wd_start")],
                [Button.inline("📢 BROADCAST USER", data="adm_broadcast_start")],
                [Button.inline("🔙 KEMBALI", data="start")]
            ]
        
        # ==========================================
        # TAMPILAN USER (Dan Admin Mode User)
        # ==========================================
        else:
            database.cek_user(user_id, sender.username if hasattr(sender, 'username') else 'User')
            saldo_asli = database.get_saldo(user_id)
            rp_saldo = f"Rp {saldo_asli:,}".replace(",", ".")

            msg = f"""
<b>🛒 HOKAGE LEGEND VPN STORE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Halo <b>{first_name}</b>! 👋
Silakan pilih kategori layanan di bawah ini.

🆔 <b>ID Anda :</b> <code>{user_id}</code>
💰 <b>Saldo :</b> <code>{rp_saldo}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

<b>👇 PILIH KATEGORI PRODUK:</b>
"""
            buttons = [
                [Button.inline("☁️ SSH/ZiVPN/OVPN", data="cat_SSH"), Button.inline("⚡ VMESS", data="cat_VMESS")],
                [Button.inline("🚀 VLESS", data="cat_VLESS"), Button.inline("🛡 TROJAN", data="cat_TROJAN")],
                [Button.inline("👻 SHADOWSOCKS", data="cat_SHADOWSOCKS"), Button.inline("💰 TOP UP SALDO", data="topup")],
                
                # 👇👇 TOMBOL YANG DITAMBAHKAN 👇👇
                [Button.inline("🔧SEWA SCRIPT VPS PREMIUM", data="gh_regis_menu")],
                # 👆👆==========================👆👆

                [Button.inline("📜 RIWAYAT TRANSAKSI", data="riwayat")],
                [Button.url("💬 HUBUNGI ADMIN", "https://t.me/HookageLegend"), Button.inline("🔙 REFRESH", data="menu_as_user")]
            ]
            
            if is_real_admin: 
                buttons.append([Button.inline("👑 KEMBALI KE ADMIN PANEL", data="menu")])
            
            buttons.append([Button.inline("🔙 MENU UTAMA", data="start")])

        if isinstance(event, events.CallbackQuery.Event):
            try:
                await event.edit(msg, buttons=buttons, parse_mode='html')
            except errors.MessageNotModifiedError:
                await event.answer("✅ Data sudah paling update!", alert=False)
            except Exception as e:
                if "not modified" in str(e):
                    await event.answer("✅ Data sudah paling update!", alert=False)
                else:
                    raise e
        else:
            await event.reply(msg, buttons=buttons, parse_mode='html')

    except Exception as e:
        try: await event.respond(f"❌ <b>ERROR:</b> {str(e)}", parse_mode='html')
        except: pass

# =================================================================
# HANDLER MANAGE USER & SALDO (ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'manage_users'))
async def manage_users_handler(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak!", alert=True)
    
    users = database.get_all_users(limit=15)
    
    msg = "<b>👥 MANAJEMEN USER & SALDO</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += "<i>Menampilkan Top 15 User (Urut Saldo):</i>\n\n"
    
    if not users:
        msg += "⚠️ Belum ada user terdaftar."
    else:
        for u in users:
            uid, uname, saldo = u
            uname = uname if uname else "Unknown"
            msg += f"🆔 <code>{uid}</code> | 💰 Rp {saldo:,}\n👤 {uname}\n───────────────────\n"
            
    msg += "\n<b>👇 PILIH AKSI:</b>"
    
    buttons = [
        [Button.inline("➕ TAMBAH SALDO", data="adm_add_saldo"), Button.inline("➖ KURANG SALDO", data="adm_min_saldo")],
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'adm_(add|min)_saldo'))
async def admin_saldo_start(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    
    action = event.data.decode('utf-8')
    tipe_aksi = "TAMBAH" if "add" in action else "KURANG"
    
    admin_states[sender.id] = 'WAIT_TARGET_ID'
    admin_context[sender.id] = {'type': tipe_aksi}
    
    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="cancel_admin_process")]]
    
    await event.edit(f"<b>📝 {tipe_aksi} SALDO USER</b>\n\nSilakan kirim <b>ID Telegram User</b>.\n(Lihat ID di list sebelumnya)\n\nAtau Klik tombol Batal dibawah.", buttons=btn_batal, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'cancel_admin_process'))
async def cancel_admin_handler(event):
    user_id = event.sender_id
    if user_id in admin_states: del admin_states[user_id]
    if user_id in admin_context: del admin_context[user_id]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", buttons=[[Button.inline("🔙 Menu Admin", data="manage_users")]], parse_mode='html')

@bot.on(events.NewMessage(incoming=True))
async def global_admin_input_handler(event):
    user_id = event.sender_id
    sender = await event.get_sender()
    text = event.raw_text.strip()
    
    # CEK STATE ADMIN DULU
    if user_id in admin_states:
        state = admin_states[user_id]
        
        # --- INSTALL ULANG OS (WAIT_OS_CREDENTIALS) ---
        if state == 'WAIT_OS_CREDENTIALS':
            if "|" not in text: 
                return await event.reply("⚠️ Format Salah! Gunakan: <code>IP|PASSWORD</code>")
            
            ip, password = text.split("|", 1)
            ip = ip.strip()
            password = password.strip()
            
            admin_context[user_id] = {'ip': ip, 'pass': password, 'target_ip': ip, 'target_pass': password}
            del admin_states[user_id]

            msg = await event.reply(f"🔄 <b>Menghubungkan ke {ip}...</b>\n1️⃣ Tahap 1: Mematikan IPv6...", parse_mode='html')

            try:
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(ip, port=22, username='root', password=password, timeout=30, banner_timeout=30)
                
                stdin, stdout, stderr = client.exec_command("sysctl -w net.ipv6.conf.all.disable_ipv6=1; sysctl -w net.ipv6.conf.default.disable_ipv6=1")
                status1 = stdout.channel.recv_exit_status()
                
                await msg.edit(f"🔄 <b>Tersambung!</b>\n2️⃣ Tahap 2: Update sistem & Install bahan...\n<i>(Ini memakan waktu 30-60 detik, mohon sabar)</i>", parse_mode='html')
                
                cmd_install = (
                    "export DEBIAN_FRONTEND=noninteractive; "
                    "apt-get -o Acquire::ForceIPv4=true update -y -qq; "
                    "apt-get -o Acquire::ForceIPv4=true install -y -qq screen curl util-linux"
                )
                stdin, stdout, stderr = client.exec_command(cmd_install)
                status2 = stdout.channel.recv_exit_status()
                
                await msg.edit(f"🔄 <b>Hampir Selesai...</b>\n3️⃣ Tahap 3: Menyiapkan Mesin Installer...", parse_mode='html')
                
                cmd_prepare = (
                    "pkill -f reinstall.sh; screen -wipe; "
                    "curl -s -O https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh; "
                    "chmod +x reinstall.sh; "
                    "screen -dmS installer bash"
                )
                stdin, stdout, stderr = client.exec_command(cmd_prepare)
                status3 = stdout.channel.recv_exit_status()
                
                client.close()

                menu_text = f"""
<b>✅ MESIN INSTALLER SIAP!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🎯 <b>Target:</b> <code>{ip}</code>

Semua bahan berhasil disiapkan.
Silakan pilih OS di bawah. Bot akan otomatis menjalankan perintah instalasi.
"""
                buttons = [
                    [Button.inline("🐧 DEBIAN 10", data="do_debian_10"), Button.inline("🐧 DEBIAN 11", data="do_debian_11")],
                    [Button.inline("🟠 UBUNTU 20.04", data="do_ubuntu_20.04"), Button.inline("🟠 UBUNTU 22.04", data="do_ubuntu_22.04")],
                    [Button.inline("❌ BATAL", data="menu")]
                ]
                await msg.edit(menu_text, buttons=buttons, parse_mode='html')

            except Exception as e:
                await msg.edit(f"❌ <b>Gagal Terhubung:</b>\n<code>{str(e)}</code>", buttons=[[Button.inline("🔙 KEMBALI", data="menu")]], parse_mode='html')
            return
        
        # -----------------------------------------------------------
        # 1. TAHAP PERTAMA: TERIMA IP & PASSWORD -> MINTA DOMAIN
        # -----------------------------------------------------------
        elif state == 'WAIT_SSH_CREDENTIALS':
            if "|" not in text:
                return await event.reply("⚠️ Format Salah! Gunakan: <code>IP|PASSWORD</code>")
            
            ip, password = text.split("|", 1)
            ip = ip.strip()
            password = password.strip()
            
            # Simpan IP & Pass ke memori sementara
            admin_context[user_id] = {
                'target_ip': ip, 
                'target_pass': password
            }
            
            # Pindah ke State Minta Domain
            admin_states[user_id] = 'WAIT_INSTALL_DOMAIN'
            
            await event.reply(
                f"✅ <b>Data VPS Diterima!</b>\n"
                f"Target: <code>{ip}</code>\n\n"
                f"Sekarang kirim <b>DOMAIN</b> yang ingin digunakan.\n"
                f"<i>Contoh: vpstore.my.id</i>",
                parse_mode='html'
            )
            return

        # -----------------------------------------------------------
        # 2. TAHAP KEDUA: TERIMA DOMAIN -> MINTA NS DOMAIN
        # -----------------------------------------------------------
        elif state == 'WAIT_INSTALL_DOMAIN':
            domain = text.strip()
            
            if "." not in domain:
                return await event.reply("⚠️ Format domain tidak valid. Coba lagi (contoh: google.com).")

            # Simpan Domain
            admin_context[user_id]['domain'] = domain
            
            # Pindah ke State Minta NS
            admin_states[user_id] = 'WAIT_INSTALL_NS'
            
            await event.reply(
                f"✅ <b>Domain:</b> <code>{domain}</code>\n\n"
                f"Sekarang kirim <b>NS DOMAIN</b> (NameServer).\n"
                f"<i>Contoh: ns.{domain}</i>", 
                parse_mode='html'
            )
            return

        # -----------------------------------------------------------
        # 3. TAHAP TERAKHIR: TERIMA NS -> EKSEKUSI INSTALL
        # -----------------------------------------------------------
        elif state == 'WAIT_INSTALL_NS':
            ns_domain = text.strip()
            
            # 👑 CEK STATUS ADMIN
            is_admin = False
            try:
                if valid(str(user_id)) == "true": is_admin = True
            except: pass

            BIAYA = 5000

            # --- LOGIC CEK SALDO (HANYA JIKA BUKAN ADMIN) ---
            if not is_admin:
                saldo_skrg = database.get_saldo(user_id)
                if saldo_skrg < BIAYA:
                    return await event.reply(f"❌ <b>Saldo Tidak Cukup!</b>\nButuh: Rp {BIAYA:,}\nSilakan Topup dulu.", parse_mode='html')
            # ------------------------------------------------

            # Ambil semua data dari context
            if user_id not in admin_context:
                return await event.reply("⚠️ Sesi habis. Ulangi proses dari awal.")
                
            ctx = admin_context[user_id]
            ip_target = ctx['target_ip']
            pass_target = ctx['target_pass']
            user_domain = ctx['domain']
            user_ns = ns_domain 
            
            # Hapus state agar tidak looping
            del admin_states[user_id]
            del admin_context[user_id]
            
            msg = await event.reply(f"🚀 <b>MEMULAI INSTALLASI...</b>\nTarget: <code>{ip_target}</code>\nDomain: <code>{user_domain}</code>", parse_mode='html')
            
            # URL SCRIPT BARU ANDA
            SCRIPT_URL = "https://raw.githubusercontent.com/hokagelegend9999/install/refs/heads/main/alphav2"
            
            try:
                # 1. POTONG SALDO DULU (HANYA JIKA BUKAN ADMIN)
                if not is_admin:
                    database.kurang_saldo(user_id, BIAYA, "Install Script VPS")

                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                # Coba connect
                client.connect(ip_target, port=22, username='root', password=pass_target, timeout=30)
                
                # --- SCRIPT WRAPPER LENGKAP (FIXED DOMAIN MANUAL) ---
                wrapper_cmd = f"""cat > /root/run_hokage.sh << 'EOF'
#!/bin/bash
# 1. Setting Log & Directory
exec > /root/install_ssh.log 2>&1
cd /root

# Force Non-Interactive (Agar tidak muncul pertanyaan [Y/n])
export DEBIAN_FRONTEND=noninteractive

# 2. Inject Variable Bot (PENTING)
export AUTO_DOMAIN="{user_domain}"
export AUTO_NS="{user_ns}"
export AUTO_CHATID="{event.chat_id}"
export AUTO_MSGID="{msg.id}"

# 3. Download Script Baru
echo "Downloading Script..."
rm -f install.sh
curl -fsSL -o install.sh {SCRIPT_URL} || wget -q -O install.sh {SCRIPT_URL}

if [ ! -f install.sh ]; then
    echo "❌ GAGAL DOWNLOAD SCRIPT!"
    exit 1
fi

chmod +x install.sh

# =======================================================
# 4. OPERASI BEDAH SCRIPT (MODIFIKASI EKSTREM)
# =======================================================

# A. UBAH KE "1" (MANUAL DOMAIN) BUKAN "2" (RANDOM)
# Ini perbaikan utamanya:
sed -i 's/read -p ".*Please select numbers.*/host="1"/g' install.sh

# B. Masukkan Domain User ke variable host1 (Biasanya variable untuk input manual)
sed -i 's/read -p ".*Subdomain:.*/host1="{user_domain}"/g' install.sh
sed -i 's/read -p ".*Input Domain:.*/host1="{user_domain}"/g' install.sh

# C. Hapus 'read -p' Press Enter di awal (Bypass Pause)
sed -i '/read -p.*Enter/d' install.sh

# D. Suntikkan Variable langsung ke dalam file (Backup Plan)
sed -i '2i AUTO_DOMAIN="{user_domain}"' install.sh
sed -i '3i AUTO_NS="{user_ns}"' install.sh

# =======================================================

# 5. Eksekusi dengan "yes" agar otomatis jawab Y
echo "Running Installer (Fully Automated Mode)..."
yes | ./install.sh

echo "=== INSTALLASI SELESAI ==="
EOF
"""
                # Eksekusi pembuatan file wrapper
                client.exec_command(wrapper_cmd)
                time.sleep(1)
                
                # Beri izin eksekusi
                client.exec_command("chmod +x /root/run_hokage.sh")
                
                # Matikan proses lama yang mungkin nyangkut
                client.exec_command("pkill -f install.sh")
                client.exec_command("screen -S install_ssh -X quit 2>/dev/null") 
                client.exec_command("screen -wipe")
                
                # Jalankan wrapper di dalam screen baru
                client.exec_command("screen -dmS install_ssh bash /root/run_hokage.sh")
                
                client.close()
                
                # PESAN SUKSES
                msg_saldo = ""
                if not is_admin:
                    sisa = database.get_saldo(user_id)
                    msg_saldo = f"\n💸 <b>Biaya:</b> Rp {BIAYA:,}\n💰 <b>Sisa Saldo:</b> Rp {sisa:,}"
                else:
                    msg_saldo = "\n👮 <b>Admin Mode:</b> Gratis (No Charge)"

                await msg.edit(
                    f"✅ <b>INSTALLASI DIMULAI!</b>"
                    f"{msg_saldo}\n"
                    f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                    f"🎯 <b>Target:</b> <code>{ip_target}</code>\n"
                    f"🌐 <b>Domain:</b> <code>{user_domain}</code>\n"
                    f"📡 <b>NS:</b> <code>{user_ns}</code>\n"
                    f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                    f"💻 <b>Cek Log:</b>\n<code>tail -f /root/install_ssh.log</code>\n\n"
                    f"💻 <b>Cek Screen:</b>\n<code>screen -r install_ssh</code>\n\n"
                    f"<i>Script berjalan otomatis (Auto-Bypass Enter & Yes).</i>",
                    parse_mode='html'
                )

            except Exception as e:
                # GAGAL -> REFUND (HANYA JIKA BUKAN ADMIN)
                if not is_admin:
                    database.tambah_saldo(user_id, BIAYA, "Refund Gagal Install Script")
                await msg.edit(f"❌ <b>Error SSH:</b> {str(e)}\n🔄 <b>Saldo telah dikembalikan (Jika terpotong).</b>")
            return
        
        # --- GITHUB ADD IP (GH_WAIT_ADD_IP) ---
        elif state == 'GH_WAIT_ADD_IP':
            parts = text.split()
            if len(parts) < 3:
                return await event.reply("⚠️ Format: username ip_address expired\nContoh: client1 1.1.1.1 2025-12-31")
            
            # 👑 CEK STATUS ADMIN
            is_admin = False
            try:
                if valid(str(user_id)) == "true": is_admin = True
            except: pass

            BIAYA = 5000
            
            if not is_admin:
                saldo_skrg = database.get_saldo(user_id)
                if saldo_skrg < BIAYA:
                    return await event.reply(f"❌ <b>Saldo Tidak Cukup!</b>\nButuh: Rp {BIAYA:,}\nSaldo: Rp {saldo_skrg:,}\n\nSilakan Topup dulu.", parse_mode='html')

            raw_username, ip_addr, expired = parts[0], parts[1], parts[2]
            tagged_username = f"{user_id}|{raw_username}"
            
            processing_msg = await event.reply("🔄 <b>Sedang menambahkan IP ke GitHub...</b>", parse_mode='html')
            
            try:
                # 🔥 FIX: TAMBAHKAN KETERANGAN TRANSAKSI 'Tambah IP'
                if not is_admin:
                    database.kurang_saldo(user_id, BIAYA, "Tambah IP VPS")

                result = github_manager.add_ip_to_github(tagged_username, ip_addr, expired)
                
                buttons = [[Button.inline("🔙 KEMBALI KE MENU", data="gh_regis_menu")]]
                
                if "✅" in result:
                    msg_info = ""
                    if not is_admin:
                        sisa_saldo = database.get_saldo(user_id)
                        msg_info = f"\n💸 <b>Terpotong:</b> Rp {BIAYA:,}\n💰 <b>Sisa Saldo:</b> Rp {sisa_saldo:,}"
                    else:
                        msg_info = "\n👮 <b>Admin Mode:</b> Gratis"

                    await processing_msg.edit(f"✅ <b>IP Berhasil Ditambahkan!</b>\nIP: <code>{ip_addr}</code>\nUser: {raw_username}{msg_info}", buttons=buttons, parse_mode='html')
                    if user_id in admin_states: del admin_states[user_id]
                else:
                    if not is_admin:
                        database.tambah_saldo(user_id, BIAYA, "Refund Gagal Tambah IP")
                    await processing_msg.edit(f"❌ <b>Gagal Menambahkan:</b>\n{result}\n\n🔄 <b>Saldo telah dikembalikan.</b>", buttons=buttons, parse_mode='html')
            
            except Exception as e:
                if not is_admin:
                    database.tambah_saldo(user_id, BIAYA, "Refund Error System")
                await processing_msg.edit(f"❌ <b>Error System:</b> {str(e)}\n🔄 <b>Saldo telah dikembalikan.</b>", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="gh_regis_menu")]], parse_mode='html')
            return

        # --- EDIT IP (GH_WAIT_EDIT_NEW_DATA) ---
        elif state == 'GH_WAIT_EDIT_NEW_DATA':
            parts = text.split()
            if len(parts) < 3:
                return await event.reply("⚠️ Format: username ip_baru expired\nContoh: agus 10.10.1.49 2026-12-29")
            
            is_admin = False
            try:
                if valid(str(user_id)) == "true": is_admin = True
            except: pass

            BIAYA = 5000
            
            if not is_admin:
                saldo_skrg = database.get_saldo(user_id)
                if saldo_skrg < BIAYA:
                    return await event.reply(f"❌ <b>Saldo Tidak Cukup!</b>\nButuh: Rp {BIAYA:,}\nSilakan Topup dulu.", parse_mode='html')

            raw_username, ip_baru, expired = parts[0], parts[1], parts[2]
            old_ip = admin_context.get(user_id, {}).get('old_ip', '')
            tagged_username = f"{user_id}|{raw_username}"
            
            try:
                # 🔥 FIX: TAMBAHKAN KETERANGAN TRANSAKSI 'Edit IP'
                if not is_admin:
                    database.kurang_saldo(user_id, BIAYA, "Edit IP VPS")

                result = github_manager.edit_ip_on_github(old_ip, tagged_username, ip_baru, expired)
                
                if "✅" in result:
                    msg_info = ""
                    if not is_admin:
                        sisa = database.get_saldo(user_id)
                        msg_info = f"\n💸 <b>Biaya:</b> Rp {BIAYA:,}\n💰 <b>Sisa Saldo:</b> Rp {sisa:,}"
                    else:
                        msg_info = "\n👮 <b>Admin Mode:</b> Gratis"

                    await event.reply(f"✅ <b>IP Berhasil Diupdate!</b>\n{result}{msg_info}")
                    del admin_states[user_id]
                    del admin_context[user_id]
                else:
                    if not is_admin:
                        database.tambah_saldo(user_id, BIAYA, "Refund Gagal Edit IP")
                    await event.reply(f"❌ Gagal: {result}\n🔄 Saldo dikembalikan.")
            except Exception as e:
                if not is_admin:
                    database.tambah_saldo(user_id, BIAYA, "Refund Error Edit IP")
                await event.reply(f"❌ Error: {str(e)}\n🔄 Saldo dikembalikan.")
            return

        # =======================================================
        # 👇 HANDLING TAMBAH SALDO ADMIN 👇
        # =======================================================
        if state == 'WAIT_TARGET_ID':
            target_id = text.strip()
            if not target_id.isdigit():
                return await event.reply("⚠️ <b>Format Salah!</b>\nID Telegram harus berupa angka.\n\nSilakan kirim ulang ID User:", parse_mode='html')

            admin_context[user_id]['target_id'] = target_id
            admin_states[user_id] = 'WAIT_SALDO_NOMINAL'
            
            tipe = admin_context[user_id]['type']
            await event.reply(f"✅ <b>Target ID:</b> <code>{target_id}</code>\n\nSilakan masukkan <b>NOMINAL SALDO</b> yang ingin di-{tipe}kan:\n(Contoh: 50000)", parse_mode='html')
            return

        elif state == 'WAIT_SALDO_NOMINAL':
            if not text.isdigit():
                return await event.reply("⚠️ Nominal harus berupa angka saja.")

            nominal = int(text)
            ctx = admin_context[user_id]
            target_id = ctx['target_id']
            tipe_aksi = ctx['type']

            try:
                if tipe_aksi == 'TAMBAH':
                    database.tambah_saldo(target_id, nominal, "Topup Manual oleh Admin")
                    pesan_sukses = f"✅ <b>SUKSES TAMBAH SALDO</b>\n\n👤 <b>Target:</b> <code>{target_id}</code>\n➕ <b>Jumlah:</b> Rp {nominal:,}"
                    pesan_notif_user = f"<b>🔔 DEPOSIT DITERIMA</b>\n\n💰 Nominal: Rp {nominal:,}\n✅ Status: Sukses"
                else:
                    database.kurang_saldo(target_id, nominal, "Dikurangi Admin")
                    pesan_sukses = f"✅ <b>SUKSES KURANG SALDO</b>\n\n👤 <b>Target:</b> <code>{target_id}</code>\n➖ <b>Jumlah:</b> Rp {nominal:,}"
                    pesan_notif_user = f"<b>🔔 SALDO DIKURANGI</b>\n\n📉 Nominal: Rp {nominal:,}"

                sisa_saldo = database.get_saldo(target_id)
                pesan_sukses += f"\n💰 <b>Saldo User Sekarang:</b> Rp {sisa_saldo:,}"

                buttons = [[Button.inline("🔙 KEMBALI KE MANAGE USER", data="manage_users")]]
                await event.reply(pesan_sukses, buttons=buttons, parse_mode='html')

                try:
                    await event.client.send_message(int(target_id), pesan_notif_user, parse_mode='html')
                except:
                    pass

            except Exception as e:
                await event.reply(f"❌ <b>Gagal Database:</b> {str(e)}")

            del admin_states[user_id]
            del admin_context[user_id]
            return

        # --- WITHDRAW HANDLERS (Sama seperti sebelumnya, tidak diubah) ---
        elif state == 'WD_WAIT_BANK':
            admin_context[user_id] = {'kode_bank': text}
            admin_states[user_id] = 'WD_WAIT_REK'
            await event.reply("Masukkan <b>Nomor Rekening/Account</b>:", parse_mode='html')
            return
        
        elif state == 'WD_WAIT_REK':
            admin_context[user_id]['nomor_akun'] = text
            admin_states[user_id] = 'WD_WAIT_NAMA'
            await event.reply("Masukkan <b>Nama Pemilik Rekening</b>:", parse_mode='html')
            return
        
        elif state == 'WD_WAIT_NAMA':
            admin_context[user_id]['nama_pemilik'] = text
            admin_states[user_id] = 'WD_WAIT_NOMINAL'
            await event.reply("Masukkan <b>NOMINAL Withdraw</b> (Angka saja):", parse_mode='html')
            return
        
        elif state == 'WD_WAIT_NOMINAL':
            if not text.isdigit():
                return await event.reply("⚠️ Harus angka saja!")
            
            nominal = int(text)
            ctx = admin_context[user_id]
            
            result = atlantic.withdraw_request(
                nominal, 
                ctx['kode_bank'], 
                ctx['nomor_akun'], 
                ctx.get('nama_pemilik', 'Admin')
            )
            
            await event.reply(f"📤 <b>Hasil Withdraw:</b>\n{result}")
            del admin_states[user_id]
            del admin_context[user_id]
            return

        # --- BROADCAST ---
        elif state == 'WAIT_BROADCAST_MSG':
            if text.lower() == '/cancel':
                del admin_states[user_id]
                return await event.reply("❌ Broadcast dibatalkan.")
            
            await event.reply(f"📢 <b>Broadcast sedang dikirim...</b>")
            
            all_users = database.get_all_user_ids()
            success = 0
            failed = 0
            
            for uid in all_users:
                try:
                    await event.client.send_message(int(uid), f"📢 <b>PESAN BROADCAST</b>\n\n{text}", parse_mode='html')
                    success += 1
                    await asyncio.sleep(0.05)
                except:
                    failed += 1
            
            await event.reply(f"✅ <b>Broadcast Selesai!</b>\n✓ Berhasil: {success}\n✗ Gagal: {failed}")
            del admin_states[user_id]
            return
        
    # =================================================================
    # JIKA BUKAN STATE ADMIN -> CEK STATE USER (Sama seperti sebelumnya)
    # =================================================================
    state = user_states.get(user_id)
    username = sender.username if sender.username else "TanpaUsername"
    
    if state == 'WAIT_MANUAL_NOMINAL':
        text = event.raw_text.strip().replace(".", "").replace(",", "")
        if not text.isdigit(): 
            return await event.reply("⚠️ Harap masukkan angka saja.")
        
        nominal = int(text)
        if nominal < 10000: 
            return await event.reply("⚠️ Minimal topup Rp 10.000.")
        
        del user_states[user_id]
        now = DT.datetime.now()
        tgl = now.strftime("%d-%m-%Y")
        jam = now.strftime("%H:%M:%S")
        file_path = '/usr/bin/kyt/modules/qris/qris.jpg'
        
        msg_to_admin = f"""
Halo Admin, Saya sudah transfer untuk Topup Saldo.
🆔 ID: {user_id}
👤 User: @{username}
💰 Nominal: Rp {nominal:,}
📅 Waktu: {tgl} {jam}
"""
        encoded_msg = urllib.parse.quote(msg_to_admin)
        link_wa = f"https://wa.me/{ADMIN_WA}?text={encoded_msg}"
        link_tg = f"https://t.me/share/url?url={encoded_msg}"

        capt = f"""
<b>💸 FORMULIR KONFIRMASI TOPUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 DATA USER</b>
<b>🆔 ID Telegram :</b> <code>{user_id}</code>
<b>👤 Username    :</b> @{username}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>💰 RINCIAN TRANSFER</b>
<b>💵 Nominal      :</b> <code>Rp {nominal:,}</code>
<b>📅 Tanggal      :</b> {tgl}
<b>🕒 Waktu        :</b> {jam} WIB
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>ℹ️ INSTRUKSI PEMBAYARAN:</b>
1. Scan QRIS di atas & Transfer sebesar <b>Rp {nominal:,}</b>.
2. Screenshot bukti transfer berhasil.
3. Klik tombol <b>KONFIRMASI</b> di bawah (WA/TG).
"""
        buttons = [
            [Button.url("🟢 KONFIRMASI KE WA", link_wa)],
            [Button.url("🔵 KONFIRMASI KE TG", link_tg)],
            [Button.inline("🔙 KEMBALI MENU", data="menu_as_user")]
        ]

        if os.path.exists(file_path):
            await event.reply(capt, file=file_path, buttons=buttons, parse_mode='html')
        else:
            await event.reply(f"⚠️ <b>Error:</b> File QRIS tidak ditemukan.\n\n{capt}", buttons=buttons, parse_mode='html')

    elif state == 'WAITING_NOMINAL':
        text = event.raw_text.strip()
        if not text.isdigit(): 
            return await event.reply("⚠️ Harap masukkan angka saja.")
        
        nominal = int(text)
        if nominal < 10000: 
            return await event.reply("⚠️ Minimal deposit Rp 10.000.")
        
        del user_states[user_id]
        msg_wait = await event.reply("🔄 <b>Sedang membuat tagihan QRIS...</b>", parse_mode='html')
        
        try:
            metode_list = atlantic.get_metode_pembayaran()
            target, tipe = None, None
            min_limit_found = 0
            
            for m in metode_list:
                nama = m['name'].lower()
                if 'qris' in nama and ('instant' in nama or 'otomatis' in nama):
                    min_val = int(m['min'])
                    if min_limit_found == 0 or min_val < min_limit_found:
                        min_limit_found = min_val
                    if min_val <= nominal <= int(m['max']):
                        target, tipe = m['metode'], m['type']
                        break
            
            if not target: 
                err_text = f"❌ <b>Nominal Tidak Didukung!</b>\nMin: Rp {min_limit_found:,}"
                return await msg_wait.edit(err_text)

            reff_id = str(random.randint(1000000000, 9999999999))
            res = atlantic.create_deposit(reff_id, nominal, tipe, target)
            
            if str(res.get('status', 'false')).lower() == 'true':
                data = res['data']
                at_id = data.get('id', '0')
                database.new_deposit(user_id, reff_id, nominal, at_id, target)
                
                bayar = data.get('nominal') + data.get('tambahan', 0) + data.get('fee', 0)
                capt = f"""
<b>✅ TAGIHAN QRIS INSTANT</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Total Bayar:</b> <code>Rp {bayar:,}</code>
<b>⏳ Expired:</b> {data.get('expired_at', '-')}
"""
                buttons_qris = [
                    [Button.inline("🔄 CEK STATUS PEMBAYARAN", data=f"cek_status_{at_id}_{reff_id}")],
                    [Button.inline("🔙 BATAL / KEMBALI", data="menu_as_user")]
                ]

                qr_content = data.get('qr_string')
                if qr_content:
                    encoded_qr = urllib.parse.quote(qr_content)
                    gen_url = f"https://api.qrserver.com/v1/create-qr-code/?size=500x500&margin=35&data={encoded_qr}"
                    r_img = requests.get(gen_url, timeout=10)
                    file_bytes = io.BytesIO(r_img.content)
                    file_bytes.name = "qrcode.png"
                    await event.client.send_file(event.chat_id, file_bytes, caption=capt, buttons=buttons_qris, parse_mode='html')
                    await msg_wait.delete()
                else:
                    await msg_wait.edit(f"❌ <b>Error:</b> QR Code tidak ditemukan.", buttons=buttons_qris)
            else:
                await msg_wait.edit(f"❌ <b>Gagal:</b> {res.get('message', 'Unknown Error')}")
        except Exception as e:
            await msg_wait.edit(f"❌ <b>System Error:</b> {str(e)}")

# =================================================================
# FUNGSI BACKGROUND MONITOR
# =================================================================
async def monitor_installation(chat_id, ip, password, os_name, client_telethon):
    import asyncio
    import paramiko
    from telethon import Button  # Pastikan mengimport Button

    print(f"[MONITOR] Memulai pemantauan untuk {ip}...")
    max_retries = 40  # 40 x 30 detik = 20 Menit batas waktu
    retry_count = 0
    
    while retry_count < max_retries:
        await asyncio.sleep(30) # Cek setiap 30 detik
        retry_count += 1
        
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # Timeout pendek saja untuk cek koneksi
            ssh.connect(ip, port=22, username='root', password=password, timeout=5)
            
            # Cek apakah screen installer masih ada
            stdin, stdout, stderr = ssh.exec_command("screen -ls")
            output = stdout.read().decode()
            
            ssh.close()
            
            if "installer" in output:
                # Masih proses install
                continue
            else:
                # Kirim Notifikasi Sukses dengan Tombol Kembali
                msg_sukses = f"""
<b>✅ Prosses Rebuild Selesai!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💻 <b>VPS:</b> <code>{ip}</code>
💿 <b>OS:</b> {os_name}
Keys: <code>{password}</code>

VPS telah berhasil diinstall ulang dan sudah kembali online.
Silakan login ulang.

💻 <b>Cek Log:</b>
<code>tail -f /root/install.log</code>
<b>Atau Tinggal Ngopi Dulu Aja..!!</b>
<code>Prosses....Rebuild...!!!</code>

"""
                # Menambahkan tombol inline
                buttons = [
                    [Button.inline("🔙 MENU UTAMA", data="menu")]
                ]
                
                await client_telethon.send_message(chat_id, msg_sukses, parse_mode='html', buttons=buttons)
                break

        except Exception as e:
            # Jika gagal konek SSH, kemungkinan VPS sedang REBOOT.
            continue

    if retry_count >= max_retries:
        # Menambahkan tombol kembali juga pada pesan timeout
        buttons = [[Button.inline("🔙 KEMBALI", data="menu")]]
        await client_telethon.send_message(chat_id, f"⚠️ <b>Timeout:</b> Pemantauan install VPS {ip} berhenti (sudah 20 menit). Cek manual.", parse_mode='html', buttons=buttons)

@bot.on(events.CallbackQuery(pattern=b'do_'))
async def os_execution_handler(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    if sender.id not in admin_context:
        return await event.answer("⚠️ Sesi habis, ulangi input IP.", alert=True)
    
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass

    BIAYA = 5000
    if not is_admin:
        saldo_skrg = database.get_saldo(sender.id)
        if saldo_skrg < BIAYA:
            return await event.answer(f"❌ Saldo Kurang! Butuh Rp {BIAYA:,}", alert=True)

    target_os = event.data.decode('utf-8').replace("do_", "").replace("_", " ")
    ctx = admin_context[sender.id]
    ip_target = ctx['ip']
    pass_target = ctx['pass']
    
    await event.edit(
        f"🚀 <b>MEMULAI INSTALASI...</b>\n"
        f"OS: {target_os.upper()}\n"
        f"Target: <code>{ip_target}</code>\n\n"
        f"<i>Bot sedang mengirim perintah ke dalam VPS...</i>",
        parse_mode='html'
    )
    
    try:
        # 🔥 FIX: TAMBAHKAN KETERANGAN TRANSAKSI
        if not is_admin:
            database.kurang_saldo(sender.id, BIAYA, "Install OS VPS")

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip_target, port=22, username='root', password=pass_target, timeout=30)
        
        wrapper_script = f"""cat > /root/run_install.sh << 'EOF'
#!/bin/bash
exec > /root/install.log 2>&1
cd /root
if command -v curl >/dev/null 2>&1; then
    curl -O https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh
else
    wget -q https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh
fi
chmod +x reinstall.sh
printf "{pass_target}\\n{pass_target}\\n" | ./reinstall.sh {target_os}
sleep 5
reboot
EOF
"""
        client.exec_command(wrapper_script)
        time.sleep(1)
        client.exec_command("chmod +x /root/run_install.sh")
        client.exec_command("screen -wipe")
        client.exec_command("screen -dmS installer bash /root/run_install.sh")
        client.close()
        
        asyncio.create_task(monitor_installation(event.chat_id, ip_target, pass_target, target_os.upper(), event.client))
        
        msg_saldo = ""
        if not is_admin:
            sisa = database.get_saldo(sender.id)
            msg_saldo = f"\n💸 <b>Biaya:</b> Rp {BIAYA:,}\n💰 <b>Sisa Saldo:</b> Rp {sisa:,}"
        else:
            msg_saldo = "\n👮 <b>Admin Mode:</b> Gratis"

        await event.edit(
            f"✅ <b>PERINTAH DIKIRIM!</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"Instalasi <b>{target_os.upper()}</b> sedang berjalan.\n"
            f"{msg_saldo}\n\n"
            f"⏳ <b>Estimasi:</b> 10-15 Menit\n"
            f"🔔 <b>Bot akan mengirim notifikasi saat selesai.</b>\n\n"
            f"💻 <b>Cek Log:</b>\n<code>tail -f /root/install.log</code>",
            buttons=[[Button.inline("🔙 MENU UTAMA", data="menu")]],
            parse_mode='html'
        )
        
        if sender.id in admin_context: del admin_context[sender.id]

    except Exception as e:
        if not is_admin:
            database.tambah_saldo(sender.id, BIAYA, "Refund Gagal Install OS")
        await event.edit(f"❌ <b>Gagal Mengirim Perintah:</b>\n{str(e)}\n\n🔄 <b>Saldo telah dikembalikan.</b>")

# =================================================================
# HANDLER CATEGORY & BUY
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'cat_'))
async def category_handler(event):
    try:
        kategori_pilih = event.data.decode('utf-8').split('_')[1]
        msg = f"<b>📦 KATEGORI: {kategori_pilih}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Silakan pilih paket:</i>\n"
        buttons = []
        found = False
        for kode, info in harga.daftar_produk.items():
            if info['service'] == kategori_pilih:
                found = True
                nama = info['nama']; harga_rp = harga.format_rupiah(info['harga'])
                buttons.append([Button.inline(f"{nama} - {harga_rp}", data=f"buy_{kode}")])
        if not found: msg += "\n❌ <i>Produk belum tersedia.</i>"
        buttons.append([Button.inline("🔙 KEMBALI", data="menu_as_user")])
        await event.edit(msg, buttons=buttons, parse_mode='html')
    except: pass

@bot.on(events.CallbackQuery(pattern=b'buy_'))
async def buy_confirm_handler(event):
    try:
        kode_produk = event.data.decode('utf-8').split('_', 1)[1]
        if kode_produk in harga.daftar_produk:
            info = harga.daftar_produk[kode_produk]
            callback_fix = f"fix_buy_{kode_produk}"
            
            msg = f"""
<b>🛒 KONFIRMASI PEMBELIAN</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📦 Paket :</b> {info['nama']}
<b>💰 Harga :</b> {harga.format_rupiah(info['harga'])}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Pastikan saldo Anda cukup.</i>
"""
            buttons = [
                [Button.inline("✅ BELI", data=callback_fix)], 
                [Button.inline("❌ BATAL", data=f"cat_{info['service']}")]
            ]
            await event.edit(msg, buttons=buttons, parse_mode='html')
    except Exception as e:
        pass

# =================================================================
# HANDLER RIWAYAT & TOPUP
# =================================================================
@bot.on(events.CallbackQuery(data=b'riwayat'))
async def history_handler(event):
    user_id = event.sender_id
    data_trx = database.get_riwayat(user_id, limit=10)
    if not data_trx: 
        msg = "❌ <b>Belum ada riwayat.</b>"
    else:
        msg = "<b>📜 10 RIWAYAT TRANSAKSI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        for row in data_trx:
            trx, tipe, jml, sts, tgl, ket = row
            icon = "🟢" if sts == 'SUCCESS' else ("🟡" if sts == 'PENDING' else "🔴")
            msg += f"<b>{icon} {tipe}</b> | Rp {jml:,}\n📅 {str(tgl).split('.')[0]}\n📝 {ket}\n───────────────────\n"
    await event.edit(msg, buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_menu_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    
    msg = """
<b>💰 PILIH METODE TOPUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih metode deposit yang Anda inginkan:

<b>1️⃣ OTOMATIS</b> (Rekomendasi)
• Saldo masuk otomatis dalam hitungan detik.
• Support QRIS Instant (Semua E-Wallet/Bank).
• Minimal Rp 10.000.

<b>2️⃣ MANUAL</b> (Alternatif)
• Transfer manual ke QRIS Admin.
• Wajib kirim bukti transfer ke Admin.
• Saldo diproses manual (Human Process).
"""
    buttons = [
        [Button.inline("⚡ QRIS INSTANT (Otomatis)", data="topup_auto")],
        [Button.inline("🏦 QRIS MANUAL (Chat Admin)", data="topup_manual")],
        [Button.inline("🔙 KEMBALI", data="menu_as_user")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_manual'))
async def topup_manual_handler(event):
    user_states[event.sender_id] = 'WAIT_MANUAL_NOMINAL'
    msg = """
<b>🏦 TOP UP MANUAL (QRIS ADMIN)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan masukkan <b>NOMINAL</b> yang ingin Anda transfer.
<i>Contoh: 50000</i>

<i>Nanti Anda akan diminta scan QRIS dan kirim bukti ke Admin.</i>
"""
    buttons = [[Button.inline("❌ BATAL", data="topup")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_auto'))
async def topup_auto_handler(event):
    user_states[event.sender_id] = 'WAITING_NOMINAL'
    msg = """
<b>⚡ TOP UP OTOMATIS (QRIS INSTANT)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan ketik nominal deposit.
🔹 <b>Minimal:</b> Rp 10.000
🔹 <b>Metode:</b> QRIS Instant (Otomatis)
<i>Contoh ketik: 15000</i>
"""
    buttons = [[Button.inline("🔙 BATAL / KEMBALI", data="topup")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'cancel_topup'))
async def cancel_topup_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    await event.edit("❌ Topup Dibatalkan.", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')

# =================================================================
# HANDLER CEK STATUS PEMBAYARAN
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'cek_status_'))
async def check_status_trx_handler(event):
    try:
        parts = event.data.decode('utf-8').split('_')
        at_id = parts[2]
        reff_id = parts[3]
        user_id = event.sender_id
        
        local_status, local_amount = database.get_trx_status(reff_id)
        if local_status == 'SUCCESS':
            return await event.answer("✅ Pembayaran ini SUDAH SUKSES!", alert=True)
            
        await event.answer("🔄 Mengecek ke server...", alert=False)
        
        res = atlantic.check_status(at_id)
        
        if str(res.get('status', 'false')).lower() == 'true':
            data = res['data']
            status_atl = data.get('status') 
            
            if status_atl == 'success':
                nominal_masuk = int(data.get('get_balance', 0))
                database.update_trx_success(reff_id)
                database.tambah_saldo(user_id, nominal_masuk, "Deposit Otomatis")
                await event.edit(f"""
<b>✅ PEMBAYARAN BERHASIL!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Saldo Masuk:</b> <code>Rp {nominal_masuk:,}</code>

<i>Terima kasih! Saldo telah ditambahkan.</i>
""", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="menu_as_user")]], parse_mode='html')

            elif status_atl == 'processing':
                await event.answer("⚠️ Mendeteksi Deposit Processing... Mencoba Instant Claim...", alert=False)
                res_inst = atlantic.req_instant_deposit(at_id, 'true')
                
                if str(res_inst.get('status', 'false')).lower() == 'true':
                    data_inst = res_inst['data']
                    nominal_masuk = int(data_inst.get('total_diterima', 0))
                    database.update_trx_success(reff_id)
                    database.tambah_saldo(user_id, nominal_masuk, "Deposit Instant (Force)")
                    await event.edit(f"""
<b>✅ PEMBAYARAN BERHASIL (INSTANT)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Saldo Masuk:</b> <code>Rp {nominal_masuk:,}</code>

<i>Deposit berhasil dicairkan secara instan.</i>
""", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="menu_as_user")]], parse_mode='html')
                else:
                    err_msg = res_inst.get('message', 'Gagal Instant')
                    await event.answer(f"⏳ Pembayaran Masuk (Processing).\n{err_msg}\nSaldo akan masuk otomatis besok.", alert=True)

            elif status_atl == 'pending':
                await event.answer(f"⏳ STATUS: PENDING\nPembayaran belum diterima sistem.", alert=True)
                
            elif status_atl in ['expired', 'failed']:
                await event.edit(f"❌ <b>TRANSAKSI GAGAL</b>\nStatus: {status_atl}", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')
            else:
                await event.answer(f"Status: {status_atl}", alert=True)
        else:
            pesan_err = res.get('message', 'Unknown Error')
            await event.answer(f"❌ Gagal Cek: {pesan_err}", alert=True)
            
    except Exception as e:
        await event.answer(f"Error System: {str(e)}", alert=True)

@bot.on(events.CallbackQuery(pattern=r"regis(?:_(\d+))?"))
async def view_registered_ips(event):
    from datetime import datetime # Import lokal untuk menghindari error missing module
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass

    # 1. Parsing Halaman
    page = 0
    if event.pattern_match.group(1):
        page = int(event.pattern_match.group(1))

    # 2. Ambil Data GitHub
    content, sha = github_manager.get_github_file()
    if not content:
        return await event.edit("❌ Gagal mengambil data.", buttons=[[Button.inline("🔙 Kembali", data="gh_regis_menu")]])

    # 3. Filter Data
    all_lines = [line.strip() for line in content.splitlines() if line.strip().startswith("###")]
    my_items = []

    if is_admin:
        # Admin melihat SEMUA data
        my_items = all_lines
    else:
        # User biasa hanya melihat data yang mengandung ID mereka
        for line in all_lines:
            parts = line.split()
            if len(parts) >= 2 and f"{user_id}|" in parts[1]: 
                my_items.append(line)

    # 4. Pagination Logic
    total_items = len(my_items)
    items_per_page = 10
    total_pages = (total_items + items_per_page - 1) // items_per_page
    
    start_idx = page * items_per_page
    end_idx = start_idx + items_per_page
    current_items = my_items[start_idx:end_idx]

    # 5. Build Pesan
    title = "📋 <b>ALL DATABASE IP (ADMIN MODE)</b>" if is_admin else "📋 <b>LIST IP SAYA</b>"
    msg = f"{title}\n"
    msg += f"Total: {total_items} IP | Halaman {page + 1}/{total_pages if total_pages > 0 else 1}\n"
    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"

    user_buttons = []
    if not current_items:
        msg += "<i>📭 Data tidak ditemukan.</i>\n"
    else:
        for idx, line in enumerate(current_items):
            parts = line.split()
            # Format: ### ID|User Expired IP Status
            full_name = parts[1]
            
            # Bersihkan tampilan nama
            display_name = full_name.split('|')[1] if '|' in full_name else full_name
            
            if is_admin and '|' in full_name:
                # Jika Admin, tampilkan ID pemiliknya juga
                owner_id = full_name.split('|')[0]
                display_name = f"{display_name} ({owner_id})"

            ip_addr = parts[3]
            exp = parts[2]
            
            # ==========================================
            # LOGIC MENGHITUNG SISA HARI EXPIRED
            # ==========================================
            try:
                # Membandingkan tanggal expired dengan hari ini
                exp_date = datetime.strptime(exp, "%Y-%m-%d").date()
                hari_ini = datetime.now().date()
                sisa_hari = (exp_date - hari_ini).days
                
                if sisa_hari > 0:
                    sisa_text = f"{sisa_hari} Hari Lagi"
                elif sisa_hari == 0:
                    sisa_text = "Hari Ini"
                else:
                    sisa_text = "Expired ❌"
            except Exception:
                # Jika format tanggal salah
                sisa_text = "Format Tgl Salah"
            # ==========================================
            
            real_idx = start_idx + idx + 1
            msg += f"<b>{real_idx}. {display_name}</b>\n"
            msg += f"   └ <code>{ip_addr}</code> (⏳ Sisa: {sisa_text})\n"
            
            # Tombol detail per user
            user_buttons.append(Button.inline(f"{real_idx}. {display_name}", data=f"manage_ip_{ip_addr}"))

    msg += "\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"

    # 6. Susun Tombol Navigasi
    grid_buttons = [user_buttons[i:i + 2] for i in range(0, len(user_buttons), 2)]
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"regis_{page - 1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"regis_{page + 1}"))
    
    final_buttons = grid_buttons
    if nav_buttons: final_buttons.append(nav_buttons)
    
    # Label tombol beda untuk admin/user
    label_add = "➕ TAMBAH IP (GRATIS)" if is_admin else "➕ TAMBAH IP (5K)"
    final_buttons.append([Button.inline(label_add, data="gh_add_start")])
    final_buttons.append([Button.inline("🔙 KEMBALI KE MENU", data="gh_regis_menu")])

    await event.edit(msg, buttons=final_buttons, parse_mode='html')

# =================================================================
# FUNGSI WITHDRAW DATA MANAGEMENT
# =================================================================
def load_wd_data():
    if not os.path.exists(WD_FILE): 
        return []
    try:
        with open(WD_FILE, 'r') as f: 
            return json.load(f)
    except: 
        return []

def save_wd_data(data):
    with open(WD_FILE, 'w') as f: 
        json.dump(data, f, indent=4)

@bot.on(events.CallbackQuery(data=b'adm_wd_start'))
async def wd_menu_start(event):
    sender_id = event.sender_id
    if valid(str(sender_id)) != "true": return
    
    if sender_id in admin_states: del admin_states[sender_id]
    
    msg = """
<b>💸 WITHDRAW CENTER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih metode pencairan saldo Atlantic:

<b>📂 DATA TERSIMPAN</b>
Gunakan data rekening yang sudah didaftarkan.

<b>🏧 INPUT MANUAL</b>
Input kode bank dan nomor rekening manual.

<b>➕ TAMBAH DATA</b>
Daftarkan rekening baru ke database.

<b>🗑️ HAPUS DATA</b>
Hapus rekening yang tersimpan.
"""
    buttons = [
        [Button.inline("📂 PILIH TUJUAN TERSIMPAN", data="wd_pick_saved")],
        [Button.inline("🏧 INPUT MANUAL", data="wd_manual_input")],
        [Button.inline("➕ TAMBAH REKENING BARU", data="wd_add_new")],
        [Button.inline("🗑️ HAPUS REKENING", data="wd_delete_menu")],
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'wd_pick_saved'))
async def wd_pick_handler(event):
    data_wd = load_wd_data()
    
    if not data_wd:
        return await event.answer("⚠️ Belum ada data rekening tersimpan.", alert=True)
    
    msg = "<b>📂 PILIH REKENING TUJUAN:</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Klik pada nama untuk withdraw ke akun tersebut.</i>"
    buttons = []
    
    for idx, item in enumerate(data_wd):
        label = f"[{item['bank']}] {item['alias']}"
        buttons.append([Button.inline(label, data=f"wd_exec_{idx}")])
    
    buttons.append([Button.inline("🔙 KEMBALI", data="adm_wd_start")])
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'wd_delete_menu'))
async def wd_delete_menu_handler(event):
    data_wd = load_wd_data()
    
    if not data_wd:
        return await event.answer("⚠️ Data kosong, tidak ada yang bisa dihapus.", alert=True)
    
    msg = "<b>🗑️ HAPUS DATA REKENING</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Klik pada nama rekening untuk <b>MENGHAPUSNYA</b> secara permanen.</i>"
    buttons = []
    
    for idx, item in enumerate(data_wd):
        label = f"❌ HAPUS: {item['alias']} ({item['bank']})"
        buttons.append([Button.inline(label, data=f"wd_del_exec_{idx}")])
    
    buttons.append([Button.inline("🔙 KEMBALI", data="adm_wd_start")])
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'wd_del_exec_'))
async def wd_delete_exec_handler(event):
    try:
        idx = int(event.data.decode('utf-8').split('_')[3])
        data_wd = load_wd_data()
        
        if 0 <= idx < len(data_wd):
            removed = data_wd.pop(idx)
            save_wd_data(data_wd)
            await event.answer(f"✅ Data '{removed['alias']}' berhasil dihapus!", alert=True)
        else:
            await event.answer("❌ Data sudah tidak ada.", alert=True)
        
        await wd_delete_menu_handler(event)
        
    except Exception as e:
        await event.answer(f"Error: {e}", alert=True)

@bot.on(events.CallbackQuery(data=b'wd_manual_input'))
async def wd_manual_handler(event):
    sender_id = event.sender_id
    admin_states[sender_id] = 'WD_WAIT_BANK'
    await event.edit("<b>🏧 INPUT MANUAL</b>\n\nMasukkan <b>KODE BANK / E-WALLET</b>\nContoh: <code>BNI</code>, <code>DANA</code>, <code>OVO</code>", parse_mode='html', buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]])

@bot.on(events.CallbackQuery(data=b'wd_add_new'))
async def wd_add_handler(event):
    sender_id = event.sender_id
    admin_states[sender_id] = 'ADDWD_BANK'
    await event.edit("<b>➕ TAMBAH DATABASE REKENING</b>\n\nMasukkan <b>KODE BANK / E-WALLET</b>\nContoh: <code>BCA</code>, <code>DANA</code>, <code>GOPAY</code>", parse_mode='html', buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]])

@bot.on(events.CallbackQuery(pattern=b'wd_exec_'))
async def wd_exec_saved_handler(event):
    sender_id = event.sender_id
    try:
        idx = int(event.data.decode('utf-8').split('_')[2])
        data_wd = load_wd_data()
        
        if idx >= len(data_wd):
            return await event.answer("⚠️ Data tidak ditemukan (mungkin sudah dihapus).", alert=True)

        selected = data_wd[idx]
        
        admin_context[sender_id] = {
            'kode_bank': selected['bank'],
            'nomor_akun': selected['rek'],
            'nama_pemilik': selected['nama']
        }
        admin_states[sender_id] = 'WD_WAIT_NOMINAL'
        
        msg = f"""
<b>✅ DATA TERPILIH</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🏦 Bank :</b> {selected['bank']}
<b>👤 Nama :</b> {selected['nama']}
<b>🔢 No   :</b> {selected['rek']}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>Silakan Masukkan NOMINAL Withdraw:</b>
<i>(Angka saja, contoh: 100000)</i>
"""
        await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]], parse_mode='html')
        
    except Exception as e:
        await event.answer(f"Error: {e}", alert=True)

# =================================================================
# HANDLER BROADCAST
# =================================================================
@bot.on(events.CallbackQuery(data=b'adm_broadcast_start'))
async def broadcast_start_handler(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": 
        return await event.answer("Akses Ditolak", alert=True)

    admin_states[sender.id] = 'WAIT_BROADCAST_MSG'
    
    msg = """
<b>📢 BROADCAST MESSAGE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan kirim <b>PESAN</b> (Teks, Gambar, atau Sticker) yang ingin disiarkan ke seluruh member bot.

<i>Ketik /cancel untuk membatalkan.</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="cancel_admin_process")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'gh_regis_menu'))
async def gh_menu_handler(event):
    sender = await event.get_sender()
    user_id = sender.id
    username = f"@{sender.username}" if sender.username else "-(No Username)"
    
    saldo_asli = database.get_saldo(user_id)
    rp_saldo = f"Rp {saldo_asli:,}".replace(",", ".")

    msg = f"""
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📝 VPS MANAGEMENT SYSTEM</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 INFO PENGGUNA:</b>
<b>🆔 ID Telegram :</b> <code>{user_id}</code>
<b>👤 Username    :</b> {username}
<b>💰 Saldo Anda  :</b> <code>{rp_saldo}</code>

<b>💳 TARIF LAYANAN (AUTO-DEBET):</b>
• ➕ Tambah/Edit/Hapus IP : <b>Rp 5.000</b>
• ☣️ Install OS / Script : <b>Rp 5.000</b>

⚠️ <i>Saldo hanya terpotong jika SUKSES melakukan aksi (Tambah/Hapus/Edit/Install).</i>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>⚡ PILIH MENU:</b>
"""
    # 👇 TAMPILAN LEBIH PRAKTIS (HANYA 3 MENU UTAMA)
    buttons = [
        [Button.inline("📋 KELOLA LIST IP (Tambah/Hapus/Edit)", data="regis")], 
        [Button.inline("☣️ INSTALL OS UBUNTU", data="install_os")],
        [Button.inline("🤖 INSTALL SCRIPT VPS", data="ssh_install_start")],
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'gh_add_start'))
async def gh_add_start(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass
    
    # JIKA BUKAN ADMIN, CEK SALDO
    if not is_admin:
        saldo = database.get_saldo(sender.id)
        if saldo < 5000:
            await event.answer("❌ Saldo Tidak Cukup!", alert=True)
            msg_gagal = f"""
<b>🚫 AKSES DITOLAK: SALDO TIDAK CUKUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya Layanan:</b> Rp 5.000
💰 <b>Saldo Anda:</b> Rp {saldo:,}

<i>Silakan isi saldo terlebih dahulu untuk menggunakan fitur ini.</i>
"""
            buttons = [
                [Button.inline("💰 TOP UP SALDO SEKARANG", data="topup")],
                [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
            ]
            return await event.edit(msg_gagal, buttons=buttons, parse_mode='html')

    admin_states[sender.id] = 'GH_WAIT_ADD_IP'
    await event.edit("<b>➕ TAMBAH IP BARU</b>\n\nSilakan kirim format:\n<code>username ip_address expired</code>\n\nContoh:\n<code>client1 192.168.1.50 2025-12-31</code>", 
                     buttons=[[Button.inline("❌ BATAL", data="gh_regis_menu")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'gh_del_start'))
async def gh_del_start(event):
    sender = await event.get_sender()
    user_id = sender.id
    
    # --- LOGIC CEK SALDO ---
    saldo = database.get_saldo(user_id)
    if saldo < 5000:
        await event.answer("❌ Saldo Tidak Cukup!", alert=True)
        msg_gagal = f"""
<b>🚫 AKSES DITOLAK: SALDO TIDAK CUKUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya Layanan:</b> Rp 5.000
💰 <b>Saldo Anda:</b> Rp {saldo:,}

<i>Silakan isi saldo terlebih dahulu untuk menggunakan fitur ini.</i>
"""
        buttons = [
            [Button.inline("💰 TOP UP SALDO SEKARANG", data="topup")],
            [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
        ]
        return await event.edit(msg_gagal, buttons=buttons, parse_mode='html')
    # -----------------------

    admin_states[sender.id] = 'GH_WAIT_DEL_IP'
    
    msg = """
<b>➖ HAPUS IP DARI GITHUB</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan kirim <b>IP Address</b> yang ingin dihapus dari database GitHub.

<i>Contoh: 192.168.1.5</i>
"""
    buttons = [[Button.inline("❌ BATAL", data="gh_regis_menu")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'gh_install_start'))
async def gh_install_start(event):
    sender = await event.get_sender()
    admin_states[sender.id] = 'GH_WAIT_INSTALL_IP'
    
    msg = """
<b>📥 GENERATE INSTALLER VPS</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan kirim <b>IP Address</b> VPS yang akan diinstall.

<i>Bot akan membuatkan command auto-install khusus untuk IP tersebut.</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="gh_regis_menu")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'ssh_install_start'))
async def ssh_install_start_handler(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass

    # --- LOGIC CEK SALDO (HANYA JIKA BUKAN ADMIN) ---
    if not is_admin:
        saldo = database.get_saldo(sender.id)
        if saldo < 5000:
            await event.answer("❌ Saldo Tidak Cukup!", alert=True)
            msg_gagal = f"""
<b>🚫 AKSES DITOLAK: SALDO TIDAK CUKUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya Layanan:</b> Rp 5.000
💰 <b>Saldo Anda:</b> Rp {saldo:,}

<i>Silakan isi saldo terlebih dahulu untuk Auto Install Script.</i>
"""
            buttons = [
                [Button.inline("💰 TOP UP SALDO SEKARANG", data="topup")],
                [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
            ]
            return await event.edit(msg_gagal, buttons=buttons, parse_mode='html')
    # ------------------------------------------------

    admin_states[sender.id] = 'WAIT_SSH_CREDENTIALS'
    
    msg = """
<b>🤖 AUTO INSTALLER VPS (VIA SSH)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Bot akan login ke VPS target dan menjalankan script secara otomatis.

<b>Format Kirim:</b>
<code>IP_VPS|PASSWORD_ROOT</code>

<b>Contoh:</b>
<code>192.168.1.5|PasSw0rd123</code>

<i>⚠️ Pastikan VPS masih fresh (belum diinstall apa-apa).</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="gh_regis_menu")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'gh_edit_list'))
async def gh_edit_list(event):
    sender = await event.get_sender()
    user_id = sender.id

    # --- CEK SALDO AWAL ---
    saldo = database.get_saldo(user_id)
    if saldo < 5000:
        await event.answer("❌ Saldo Tidak Cukup!", alert=True)
        msg_gagal = f"""
<b>🚫 AKSES DITOLAK: SALDO TIDAK CUKUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya Layanan:</b> Rp 5.000
💰 <b>Saldo Anda:</b> Rp {saldo:,}

<i>Silakan isi saldo terlebih dahulu untuk mengedit IP.</i>
"""
        buttons = [
            [Button.inline("💰 TOP UP SALDO SEKARANG", data="topup")],
            [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
        ]
        return await event.edit(msg_gagal, buttons=buttons, parse_mode='html')
    # ----------------------

    content, sha = github_manager.get_github_file()
    if not content:
        return await event.answer("❌ Gagal mengambil data GitHub", alert=True)
    
    lines = [line.strip() for line in content.splitlines() if line.strip() and line.startswith("###")]
    if not lines:
        return await event.answer("⚠️ Tidak ada IP terdaftar", alert=True)

    buttons = []
    for line in lines:
        parts = line.split()
        if len(parts) >= 4:
            name = parts[1]
            ip = parts[3]
            buttons.append([Button.inline(f"✏️ {name} ({ip})", data=f"gh_edit_do_{ip}")])
    
    buttons.append([Button.inline("🔙 BATAL", data="gh_regis_menu")])
    await event.edit("<b>✏️ PILIH USER UNTUK DIEDIT</b>\n\nSilakan klik nama user di bawah untuk mengubah datanya:", buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=re.compile(b"gh_edit_do_(.*)")))
async def gh_edit_prompt(event):
    ip_lama = event.pattern_match.group(1).decode('utf-8')
    sender = await event.get_sender()
    
    # --- CEK SALDO (Rp 5.000) ---
    BIAYA = 5000
    saldo = database.get_saldo(sender.id)
    if saldo < BIAYA:
        return await event.answer(f"❌ Saldo Tidak Cukup! Butuh Rp {BIAYA:,}", alert=True)
    # ----------------------------

    admin_states[sender.id] = 'GH_WAIT_EDIT_NEW_DATA'
    admin_context[sender.id] = {'old_ip': ip_lama}
    
    msg = f"""
<b>✏️ EDIT DATA USER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Target IP: <code>{ip_lama}</code>

Kirim data <b>BARU</b> dengan format:
<code>username ip_baru expired</code>

Contoh:
<code>agus 10.10.1.49 2026-12-29</code>

<i>⚠️ Saldo Rp 5.000 akan terpotong setelah sukses.</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data=f"manage_ip_{ip_lama}")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'install_os'))
async def install_os_start(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass
    
    # JIKA BUKAN ADMIN, CEK SALDO
    if not is_admin:
        saldo = database.get_saldo(sender.id)
        if saldo < 5000:
            await event.answer("❌ Saldo Tidak Cukup!", alert=True)
            msg_gagal = f"""
<b>🚫 AKSES DITOLAK: SALDO TIDAK CUKUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya Layanan:</b> Rp 5.000
💰 <b>Saldo Anda:</b> Rp {saldo:,}

<i>Silakan isi saldo terlebih dahulu untuk Reinstall VPS.</i>
"""
            buttons = [
                [Button.inline("💰 TOP UP SALDO SEKARANG", data="topup")],
                [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
            ]
            return await event.edit(msg_gagal, buttons=buttons, parse_mode='html')
    
    # PROSES LANJUT
    admin_states[sender.id] = 'WAIT_OS_CREDENTIALS'
    msg = """
<b>☣️ INSTALL ULANG OS (REMOTE VPS)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Kirim <b>IP</b> dan <b>PASSWORD</b> VPS target.

<b>Format:</b> <code>IP|PASSWORD</code>
<b>Contoh:</b> <code>103.18.11.20|Hokage123</code>

⚠️ <i>Pastikan VPS bisa diakses via SSH root.</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="gh_regis_menu")]], parse_mode='html')
    
@bot.on(events.NewMessage(incoming=True))
async def global_input_handler(event):
    user_id = event.sender_id
    sender = await event.get_sender()
    text = event.raw_text.strip()
    
    # ============ HANDLER INSTALL OS ============
    if user_id in admin_states and admin_states[user_id] == 'WAIT_OS_CREDENTIALS':
        if "|" not in text:
            return await event.reply("⚠️ Format Salah! Gunakan: <code>IP|PASSWORD</code>", parse_mode='html')
        
        ip, password = text.split("|", 1)
        ip = ip.strip()
        password = password.strip()
        
        # Simpan credentials
        admin_context[user_id] = {
            'ip': ip, 
            'pass': password,
            'target_ip': ip, 
            'target_pass': password
        }
        del admin_states[user_id]
        
        msg = await event.reply(f"🔄 <b>Menyiapkan VPS {ip}...</b>\n━━━━━━━━━━━━━━━━━━━━━", parse_mode='html')
        
        try:
            import paramiko
            import time
            
            # KONEKSI SSH
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip, port=22, username='root', password=password, timeout=30, banner_timeout=30)
            
            await msg.edit("🔄 <b>✓ Terhubung ke VPS</b>\n📡 Mematikan IPv6...", parse_mode='html')
            client.exec_command("sysctl -w net.ipv6.conf.all.disable_ipv6=1")
            client.exec_command("sysctl -w net.ipv6.conf.default.disable_ipv6=1")
            time.sleep(1)
            
            # ============ CEK OS VPS ============
            stdin, stdout, stderr = client.exec_command("cat /etc/os-release | grep PRETTY_NAME || echo 'Unknown'")
            os_version = stdout.read().decode().strip()
            await msg.edit(f"🔄 <b>✓ IPv6 dimatikan</b>\n💻 OS Saat Ini: {os_version[:50]}...\n📦 Install dependencies...", parse_mode='html')
            
            # ============ INSTALL SCREEN & DEPENDENCIES ============
            commands = [
                "apt-get update -y -qq",
                "apt-get install -y -qq screen curl wget tmux",
                "apt-get install -y -qq openssh-server",
            ]
            
            for cmd in commands:
                client.exec_command(cmd)
                time.sleep(2)
            
            # ============ CEK SCREEN ============
            stdin, stdout, stderr = client.exec_command("which screen || echo 'no_screen'")
            screen_path = stdout.read().decode().strip()
            
            if 'no_screen' in screen_path or not screen_path:
                await msg.edit("🔄 <b>⚠️ Screen tidak ada</b>\n📦 Install ulang screen...", parse_mode='html')
                client.exec_command("apt-get install screen -y --fix-missing")
                time.sleep(3)
            
            # ============ DOWNLOAD REINSTALL SCRIPT ============
            await msg.edit("🔄 <b>✓ Dependencies siap</b>\n📥 Download script installer...", parse_mode='html')
            
            # Hapus file lama
            client.exec_command("rm -f /root/reinstall.sh")
            client.exec_command("rm -f /root/install.sh")
            client.exec_command("rm -f /root/install.log")
            
            # Download dengan multiple methods
            download_commands = [
                "wget -q -O /root/reinstall.sh https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh",
                "curl -fsSL -o /root/reinstall.sh https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh",
                "wget --no-check-certificate -q -O /root/reinstall.sh https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh"
            ]
            
            for cmd in download_commands:
                client.exec_command(cmd)
                time.sleep(1)
            
            # Chmod
            client.exec_command("chmod 755 /root/reinstall.sh")
            client.exec_command("chmod +x /root/reinstall.sh")
            time.sleep(1)
            
            # ============ VERIFIKASI FILE ADA ============
            stdin, stdout, stderr = client.exec_command("ls -la /root/reinstall.sh || echo 'FILE_NOT_FOUND'")
            file_check = stdout.read().decode()
            
            if 'FILE_NOT_FOUND' in file_check:
                await msg.edit("❌ <b>Gagal download script!</b>\n🔧 Mencoba metode alternatif...", parse_mode='html')
                
                # Download via raw content
                client.exec_command("wget -q -O /root/reinstall.sh https://bin456789.github.io/reinstall/reinstall.sh")
                time.sleep(2)
                client.exec_command("chmod +x /root/reinstall.sh")
            
            # ============ METHOD 1: EKSEKUSI LANGSUNG DI SCREEN ============
            await msg.edit("🔄 <b>✓ Script siap</b>\n🚀 Menjalankan installer...", parse_mode='html')
            
            # Bersihkan session screen lama
            client.exec_command("screen -X -S installer quit 2>/dev/null")
            client.exec_command("screen -wipe 2>/dev/null")
            client.exec_command("tmux kill-session -t installer 2>/dev/null")
            time.sleep(1)
            
            # ===== EKSEKUSI DENGAN ECHO PASSWORD =====
            # Format: echo "password" | /root/reinstall.sh ubuntu 20.04 && reboot
            
            install_cmd = f"echo '{password}' | /root/reinstall.sh ubuntu 20.04"
            reboot_cmd = "reboot"
            
            # Jalankan di screen
            screen_cmd = f'screen -dmS installer bash -c "{install_cmd} && {reboot_cmd}"'
            client.exec_command(screen_cmd)
            time.sleep(3)
            
            # Cek apakah screen berjalan
            stdin, stdout, stderr = client.exec_command("screen -ls | grep installer || tmux ls | grep installer || echo 'SCREEN_FAILED'")
            screen_result = stdout.read().decode()
            
            # ============ CEK PROSES BERJALAN ============
            stdin, stdout, stderr = client.exec_command("ps aux | grep -v grep | grep reinstall || echo 'PROCESS_NOT_FOUND'")
            process_check = stdout.read().decode()
            
            # ============ GITHUB MANAGER: TAMBAH IP OTOMATIS ============
            github_status = "❌ GAGAL"
            github_message = ""
            
            try:
                # Ambil username dari context atau gunakan default
                username = "vps_" + ip.replace('.', '_')
                exp_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
                
                # Panggil fungsi dari github_manager
                success, message = github_manager.add_ip(username, ip, exp_date)
                
                if success:
                    github_status = "✅ BERHASIL"
                    github_message = f"IP {ip} terdaftar dengan username {username}"
                else:
                    github_status = "❌ GAGAL"
                    github_message = message
            except Exception as e:
                github_status = "❌ ERROR"
                github_message = str(e)
            
            client.close()
            
            # ============ TAMPILKAN HASIL ============
            if 'SCREEN_FAILED' not in screen_result and 'PROCESS_NOT_FOUND' not in process_check:
                status_text = f"""
<b>✅✅ INSTALLASI BERHASIL DIMULAI! ✅✅</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🎯 <b>VPS TARGET:</b> <code>{ip}</code>
🔑 <b>PASSWORD:</b> <code>{password}</code>
💿 <b>OS BARU:</b> UBUNTU 20.04
━━━━━━━━━━━━━━━━━━━━━
📊 <b>STATUS INSTALLASI:</b>
• 🟢 SCREEN: <b>AKTIF</b> (installer)
• 🟢 PROCESS: <b>RUNNING</b>
• ⏱ ESTIMASI: <b>10-15 Menit</b>
• 🔁 REBOOT: <b>OTOMATIS</b>
━━━━━━━━━━━━━━━━━━━━━
📋 <b>GITHUB REGISTRATION:</b>
• {github_status}
• {github_message}
━━━━━━━━━━━━━━━━━━━━━
💻 <b>CEK PROGRESS:</b>
<code>ssh root@{ip}</code>
<code>screen -r installer</code>
<code>tail -f /root/install.log</code>

📝 <b>LOG FILE:</b>
<code>cat /root/install.log</code>
"""
            else:
                # FALLBACK: Jalankan dengan nohup
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(ip, port=22, username='root', password=password, timeout=30)
                
                nohup_cmd = f"nohup bash -c 'echo {password} | /root/reinstall.sh ubuntu 20.04 && reboot' > /root/install.log 2>&1 &"
                client.exec_command(nohup_cmd)
                time.sleep(2)
                client.close()
                
                status_text = f"""
<b>✅ INSTALLASI DIMULAI (FALLBACK MODE)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🎯 <b>VPS:</b> <code>{ip}</code>
🔑 <b>Password:</b> <code>{password}</code>
💿 <b>OS:</b> UBUNTU 20.04
━━━━━━━━━━━━━━━━━━━━━
⚠️ <b>SCREEN TIDAK BEKERJA</b>
• Menggunakan NOHUP sebagai pengganti
• Proses tetap berjalan di background
━━━━━━━━━━━━━━━━━━━━━
📋 <b>GITHUB REGISTRATION:</b>
• {github_status}
• {github_message}
━━━━━━━━━━━━━━━━━━━━━
💻 <b>CEK PROGRESS:</b>
<code>ssh root@{ip}</code>
<code>tail -f /root/install.log</code>
"""
            
            buttons = [
                [Button.inline("🔄 CEK STATUS INSTALL", data=f"check_install_{ip}")],
                [Button.inline("📋 LIHAT IP GITHUB", data="regis")],
                [Button.inline("🔙 MENU UTAMA", data="menu")]
            ]
            
            await msg.edit(status_text, buttons=buttons, parse_mode='html')
            
        except paramiko.AuthenticationException:
            await msg.edit("❌ <b>Gagal Login!</b>\nPassword salah atau root login tidak diizinkan.", 
                          buttons=[[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]], parse_mode='html')
        except paramiko.SSHException as e:
            await msg.edit(f"❌ <b>Koneksi SSH Gagal:</b>\n<code>{str(e)}</code>\n\nCek firewall atau SSH service.", 
                          buttons=[[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]], parse_mode='html')
        except Exception as e:
            await msg.edit(f"❌ <b>Error Sistem:</b>\n<code>{str(e)}</code>\n\nHubungi Admin.", 
                          buttons=[[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]], parse_mode='html')
        
        return  # STOP

# =================================================================
# HANDLER CEK STATUS INSTALL
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'check_install_'))
async def check_install_status(event):
    user_id = event.sender_id
    ip = event.data.decode('utf-8').replace('check_install_', '')
    
    # Cari password dari context
    password = None
    if user_id in admin_context:
        password = admin_context[user_id].get('pass')
    
    if not password:
        return await event.answer("⚠️ Sesi habis, tidak ada data VPS tersimpan", alert=True)
    
    await event.answer("🔄 Mengecek status instalasi...", alert=False)
    
    try:
        import paramiko
        
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, port=22, username='root', password=password, timeout=10)
        
        # 1. Cek screen
        stdin, stdout, stderr = client.exec_command("screen -ls | grep installer || echo 'NO_SCREEN'")
        screen_status = stdout.read().decode().strip()
        
        # 2. Cek proses reinstall
        stdin, stdout, stderr = client.exec_command("ps aux | grep -v grep | grep reinstall || echo 'NO_PROCESS'")
        process_status = stdout.read().decode().strip()
        
        # 3. Cek log file
        stdin, stdout, stderr = client.exec_command("tail -n 20 /root/install.log 2>/dev/null || echo 'LOG_NOT_FOUND'")
        log_content = stdout.read().decode().strip()
        
        # 4. Cek apakah VPS masih hidup
        stdin, stdout, stderr = client.exec_command("uptime | cut -d ',' -f 1")
        uptime = stdout.read().decode().strip()
        
        client.close()
        
        # Format pesan
        msg = f"<b>🔍 STATUS INSTALLASI VPS {ip}</b>\n━━━━━━━━━━━━━━━━━━━━━\n"
        
        msg += f"<b>🖥 UPTIME:</b> {uptime}\n"
        
        if 'NO_SCREEN' in screen_status:
            msg += "❌ <b>SCREEN:</b> TIDAK AKTIF\n"
        else:
            msg += f"✅ <b>SCREEN:</b> AKTIF\n<code>{screen_status[:100]}</code>\n"
        
        if 'NO_PROCESS' in process_status:
            msg += "❌ <b>PROSES INSTALL:</b> TIDAK BERJALAN\n"
            msg += "⚠️ Installasi mungkin sudah selesai atau gagal.\n"
        else:
            msg += f"✅ <b>PROSES INSTALL:</b> BERJALAN\n<code>{process_status[:100]}</code>\n"
        
        msg += f"\n<b>📋 LOG INSTALLASI (20 baris terakhir):</b>\n"
        msg += f"<code>{log_content[:500]}</code>\n"
        
        buttons = [[Button.inline("🔙 KEMBALI", data="menu")]]
        await event.edit(msg, buttons=buttons, parse_mode='html')
        
    except Exception as e:
        await event.answer(f"❌ Gagal konek ke VPS: {str(e)}", alert=True)
@bot.on(events.CallbackQuery(pattern=b'os_install_'))
async def os_install_exec_handler(event):
    user_id = event.sender_id
    
    # --- LOGIC CEK SALDO ---
    BIAYA = 5000
    saldo_skrg = database.get_saldo(user_id)
    if saldo_skrg < BIAYA:
        return await event.answer(f"❌ Saldo Kurang! Butuh Rp {BIAYA:,}", alert=True)
    # -----------------------

    # Parse data: os_install_103.127.97.242|ubuntu20.04
    data = event.data.decode('utf-8').replace('os_install_', '')
    if '|' not in data: return await event.answer("❌ Format data salah!", alert=True)
    
    ip, os_type = data.split('|', 1)
    
    # Ambil password (pastikan user sudah input di tahap sebelumnya)
    password = None
    if user_id in admin_context and 'pass' in admin_context[user_id]:
        password = admin_context[user_id]['pass']
    
    if not password:
        return await event.answer("⚠️ Sesi habis! Ulangi dari menu Install OS.", alert=True)

    # ... (MAPPING OS CODE TETAP SAMA) ...
    os_map = {'ubuntu20.04': 'ubuntu 20.04', 'ubuntu22.04': 'ubuntu 22.04', 'debian10': 'debian 10'}
    os_full = os_map.get(os_type, os_type.replace('.', ' '))

    await event.edit(f"🚀 <b>MEMPROSES ORDER...</b>\nMohon tunggu Agak Lama Tinggalin Ngopii Aja dulu...", parse_mode='html')

    try:
        # 1. POTONG SALDO
        database.kurang_saldo(user_id, BIAYA)
        
        import paramiko
        import time
        
        # Koneksi SSH
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, port=22, username='root', password=password, timeout=30)
        
        # ... (EKSEKUSI PERINTAH REINSTALL TETAP SAMA) ...
        install_cmd = f"echo '{password}' | /root/reinstall.sh {os_full} && reboot"
        cmd_screen = f'screen -S installer -X stuff "{install_cmd}\\n"'
        client.exec_command(cmd_screen)
        
        # Verifikasi sukses kirim perintah
        stdin, stdout, stderr = client.exec_command("screen -ls | grep installer")
        screen_check = stdout.read().decode()
        client.close()
        
        # SUKSES
        sisa = database.get_saldo(user_id)
        if 'installer' in screen_check:
             status_text = f"""
<b>✅ INSTALLASI BERHASIL DIMULAI!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💸 <b>Biaya:</b> Rp {BIAYA:,}
💰 <b>Sisa Saldo:</b> Rp {sisa:,}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🎯 <b>VPS:</b> <code>{ip}</code>
💿 <b>OS:</b> {os_full.upper()}
⏱ <b>Estimasi:</b> 10-15 Menit
"""
        else:
             # Fallback logic (sama seperti sebelumnya)
             status_text = f"✅ <b>Installasi Dimulai (Mode Nohup)</b>\nBiaya: Rp {BIAYA:,}"

        # Bersihkan context
        if user_id in admin_context: del admin_context[user_id]
        
        buttons = [
            [Button.inline("🔍 CEK STATUS SCREEN", data=f"check_screen_{ip}")],
            [Button.inline("🔙 KEMBALI", data="gh_regis_menu")]
        ]
        await event.edit(status_text, buttons=buttons, parse_mode='html')
        
    except Exception as e:
        # GAGAL KONEKSI/ERROR -> REFUND
        database.tambah_saldo(user_id, BIAYA)
        await event.edit(f"❌ <b>GAGAL (REFUNDED):</b>\n{str(e)}\n\n🔄 Saldo Rp {BIAYA:,} telah dikembalikan.", buttons=[[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]], parse_mode='html')
                        
# =================================================================
# HANDLER CEK STATUS SCREEN
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'check_screen_'))
async def check_screen_handler(event):
    ip = event.data.decode('utf-8').replace('check_screen_', '')
    user_id = event.sender_id
    
    if user_id not in admin_context:
        return await event.answer("⚠️ Sesi habis, tidak ada data VPS tersimpan", alert=True)
    
    password = admin_context[user_id].get('pass') if user_id in admin_context else None
    
    if not password:
        return await event.answer("⚠️ Password tidak ditemukan", alert=True)
    
    await event.answer("🔄 Mengecek screen session...", alert=False)
    
    try:
        import paramiko
        
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, port=22, username='root', password=password, timeout=10)
        
        # Cek apakah screen session 'installer' ada
        stdin, stdout, stderr = client.exec_command("screen -ls | grep installer || echo 'NOT_FOUND'")
        result = stdout.read().decode().strip()
        
        # Cek proses reinstall
        stdin, stdout, stderr = client.exec_command("ps aux | grep -v grep | grep reinstall || echo 'NOT_RUNNING'")
        process = stdout.read().decode().strip()
        
        client.close()
        
        msg = f"<b>🔍 STATUS SCREEN DI VPS {ip}</b>\n━━━━━━━━━━━━━━━━━━━━━\n"
        
        if 'NOT_FOUND' in result:
            msg += "❌ <b>Screen 'installer':</b> TIDAK DITEMUKAN\n"
        else:
            msg += f"✅ <b>Screen 'installer':</b> AKTIF\n<code>{result}</code>\n"
        
        if 'NOT_RUNNING' in process:
            msg += "❌ <b>Proses Install:</b> TIDAK BERJALAN\n"
            msg += "⚠️ Installasi mungkin sudah selesai atau gagal.\n"
        else:
            msg += f"✅ <b>Proses Install:</b> BERJALAN\n<code>{process[:200]}...</code>\n"
        
        msg += "\n💻 <b>Command:</b> <code>screen -r installer</code>"
        
        buttons = [[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]]
        await event.edit(msg, buttons=buttons, parse_mode='html')
        
    except Exception as e:
        await event.answer(f"❌ Gagal konek: {str(e)}", alert=True)
        
# =================================================================
# HANDLER UNTUK OS LAINNYA (DEBIAN, UBUNTU VERSI LAIN)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'os_install_'))
async def os_install_other_handler(event):
    user_id = event.sender_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak!", alert=True)
    
    # Format: os_install_103.127.97.242|ubuntu22.04
    data = event.data.decode('utf-8').replace('os_install_', '')
    
    if '|' not in data:
        return await event.answer("❌ Format data salah!", alert=True)
    
    ip, os_type = data.split('|', 1)
    
    # Ambil password dari context
    password = None
    if user_id in admin_context:
        password = admin_context[user_id].get('pass')
    
    if not password:
        return await event.answer("⚠️ Sesi habis! Ulangi dari menu Install OS.", alert=True)
    
    # Mapping OS
    os_map = {
        'debian10': 'debian 10',
        'debian11': 'debian 11',
        'debian12': 'debian 12',
        'ubuntu20.04': 'ubuntu 20.04',
        'ubuntu22.04': 'ubuntu 22.04',
        'ubuntu24.04': 'ubuntu 24.04'
    }
    
    os_full = os_map.get(os_type, os_type.replace('.', ' '))
    
    await event.edit(f"🚀 <b>INSTALL {os_full.upper()} DI {ip}...</b>", parse_mode='html')
    
    try:
        import paramiko
        import time
        
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, port=22, username='root', password=password, timeout=30)
        
        # Buat script installer
        create_script = f"""cat > /root/install.sh << 'EOF'
#!/bin/bash
cd /root
echo "{password}" | /root/reinstall.sh {os_full}
reboot
EOF
chmod +x /root/install.sh
"""
        client.exec_command(create_script)
        time.sleep(1)
        
        # Hapus screen lama & buat baru
        client.exec_command("screen -X -S installer quit 2>/dev/null")
        client.exec_command("screen -wipe 2>/dev/null")
        time.sleep(1)
        
        # Jalankan di screen
        client.exec_command(f"screen -dmS installer bash -c '/root/install.sh'")
        time.sleep(2)
        
        client.close()
        
        await event.edit(f"""
<b>✅ INSTALLASI {os_full.upper()} DIMULAI!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🎯 <b>VPS:</b> <code>{ip}</code>
💿 <b>OS:</b> {os_full.upper()}
🔑 <b>Password:</b> <code>{password}</code>
━━━━━━━━━━━━━━━━━━━━━
⏱ <b>Estimasi:</b> 10-15 Menit
🔄 <b>Reboot:</b> OTOMATIS
━━━━━━━━━━━━━━━━━━━━━
💻 <b>Cek Progress:</b>
<code>ssh root@{ip}</code>
<code>screen -r installer</code>
""", buttons=[[Button.inline("🔙 MENU UTAMA", data="menu")]], parse_mode='html')
        
        if user_id in admin_context:
            del admin_context[user_id]
        
    except Exception as e:
        await event.edit(f"❌ <b>Gagal:</b> {str(e)}", 
                        buttons=[[Button.inline("🔙 KEMBALI", data="gh_regis_menu")]], parse_mode='html')
                        
@bot.on(events.CallbackQuery(pattern=b'manage_ip_'))
async def manage_single_ip_handler(event):
    ip_target = event.data.decode('utf-8').split('manage_ip_')[1]
    sender = await event.get_sender()
    user_id = str(sender.id)

    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass

    content, _ = github_manager.get_github_file()
    lines = [l.strip() for l in content.splitlines() if l.strip().startswith("###")]
    
    found_data = None
    for line in lines:
        if ip_target in line:
            # Jika Admin, ambil data apapun. Jika User, harus ada ID-nya di username.
            if is_admin or f"{user_id}|" in line:
                found_data = line.split()
                break
            
    if not found_data:
        return await event.answer("🚫 Akses Ditolak: Data tidak ditemukan atau bukan milik Anda!", alert=True)

    # Parse Data
    full_name = found_data[1]
    name = full_name.split('|')[1] if '|' in full_name else full_name
    expired = found_data[2]
    status = found_data[4] if len(found_data) > 4 else "ON"

    biaya_msg = "(GRATIS)" if is_admin else "(Biaya Rp 5.000)"

    msg = f"""
<b>⚙️ ATUR DATA VPS</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Client :</b> {name}
<b>📡 IP Addr:</b> <code>{ip_target}</code>
<b>📅 Expired:</b> {expired}
<b>🔌 Status :</b> {status}

<i>Pilih aksi {biaya_msg}:</i>
"""
    buttons = [
        [Button.inline("✏️ EDIT DATA", data=f"gh_edit_do_{ip_target}")],
        [Button.inline("🗑️ HAPUS IP", data=f"confirm_del_{ip_target}")],
        [Button.inline("🔙 KEMBALI", data="regis")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')
    
@bot.on(events.CallbackQuery(pattern=b'confirm_del_'))
async def confirm_delete_ip(event):
    ip_target = event.data.decode('utf-8').split('confirm_del_')[1]
    sender = await event.get_sender()
    user_id = str(sender.id)

    # 👑 CEK STATUS ADMIN
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass
    
    # --- CEK SALDO (Hanya jika BUKAN Admin) ---
    BIAYA = 5000
    if not is_admin:
        saldo = database.get_saldo(sender.id)
        if saldo < BIAYA:
            return await event.answer(f"❌ Saldo Tidak Cukup! Butuh Rp {BIAYA:,}", alert=True)
    # ----------------------------

    msg_biaya = "<b>GRATIS (Admin)</b>" if is_admin else f"💸 <b>Biaya:</b> Rp {BIAYA:,}"

    msg = f"""
<b>⚠️ KONFIRMASI PENGHAPUSAN</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Apakah Anda yakin ingin menghapus IP ini?
<b>IP:</b> <code>{ip_target}</code>

{msg_biaya}
<i>Tindakan ini tidak dapat dibatalkan.</i>
"""
    buttons = [
        [Button.inline("✅ YA, HAPUS SEKARANG", data=f"exec_del_{ip_target}")],
        [Button.inline("❌ BATAL", data=f"manage_ip_{ip_target}")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'exec_del_'))
async def execute_delete_ip(event):
    ip_target = event.data.decode('utf-8').split('exec_del_')[1]
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    is_admin = False
    try:
        if valid(user_id) == "true": is_admin = True
    except: pass
    
    BIAYA = 5000

    if not is_admin:
        saldo = database.get_saldo(sender.id)
        if saldo < BIAYA:
            return await event.answer(f"❌ Saldo Kurang! Butuh Rp {BIAYA:,}", alert=True)

    processing_msg = await event.edit("🔄 <b>Sedang menghapus...</b>", parse_mode='html')
    
    try:
        # 🔥 FIX: TAMBAHKAN KETERANGAN TRANSAKSI
        if not is_admin:
            database.kurang_saldo(sender.id, BIAYA, "Hapus IP VPS")

        result = github_manager.remove_ip_from_github(ip_target)
        
        buttons = [[Button.inline("🔙 KEMBALI KE LIST", data="regis")]]
        
        if "✅" in result:
            msg_saldo = ""
            if not is_admin:
                sisa = database.get_saldo(sender.id)
                msg_saldo = f"\n💸 <b>Biaya:</b> Rp {BIAYA:,}\n💰 <b>Sisa Saldo:</b> Rp {sisa:,}"
            else:
                msg_saldo = "\n👮 <b>Admin Mode:</b> Gratis"

            await processing_msg.edit(
                f"✅ <b>BERHASIL DIHAPUS!</b>\n\n"
                f"IP <code>{ip_target}</code> telah dihapus dari database."
                f"{msg_saldo}", 
                buttons=buttons, 
                parse_mode='html'
            )
        else:
            # REFUND
            if not is_admin:
                database.tambah_saldo(sender.id, BIAYA, "Refund Gagal Hapus IP")
            await processing_msg.edit(f"❌ <b>GAGAL:</b>\n{result}\n\n🔄 <b>Saldo Aman.</b>", buttons=buttons, parse_mode='html')
            
    except Exception as e:
        if not is_admin:
            database.tambah_saldo(sender.id, BIAYA, "Refund Error Hapus IP")
        await processing_msg.edit(f"❌ Error System: {str(e)}\n🔄 Saldo dikembalikan.", buttons=[[Button.inline("🔙 KEMBALI", data="regis")]])